import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-8c17ee28/health", (c) => {
  return c.json({ status: "ok" });
});

// Weather data endpoint
app.get("/make-server-8c17ee28/weather/:location", async (c) => {
  try {
    const location = c.req.param("location");
    const cachedWeather = await kv.get(`weather:${location}`);
    
    if (cachedWeather) {
      return c.json(cachedWeather);
    }

    // Mock weather data (in production, this would call actual weather APIs)
    const weatherData = {
      location: location,
      temperature: Math.floor(Math.random() * 15) + 25, // 25-40°C
      condition: ['sunny', 'cloudy', 'rainy'][Math.floor(Math.random() * 3)],
      humidity: Math.floor(Math.random() * 40) + 40, // 40-80%
      windSpeed: Math.floor(Math.random() * 20) + 5, // 5-25 km/h
      visibility: Math.floor(Math.random() * 5) + 8, // 8-12 km
      pressure: Math.floor(Math.random() * 50) + 1000, // 1000-1050 hPa
      forecast: [
        { day: 'Today', high: 32, low: 24, condition: 'sunny', icon: '☀️' },
        { day: 'Tomorrow', high: 30, low: 22, condition: 'cloudy', icon: '☁️' },
        { day: 'Thu', high: 28, low: 20, condition: 'rainy', icon: '🌧️' },
        { day: 'Fri', high: 31, low: 23, condition: 'sunny', icon: '☀️' },
        { day: 'Sat', high: 33, low: 25, condition: 'sunny', icon: '☀️' },
      ],
      alerts: [
        { type: 'Heat Wave', message: 'High temperature expected for next 2 days', severity: 'medium' },
      ],
      timestamp: new Date().toISOString()
    };

    // Cache for 1 hour
    await kv.set(`weather:${location}`, weatherData);
    return c.json(weatherData);
  } catch (error) {
    console.log('Weather API error:', error);
    return c.json({ error: 'Failed to fetch weather data' }, 500);
  }
});

// Market prices endpoint
app.get("/make-server-8c17ee28/market-prices", async (c) => {
  try {
    const cachedPrices = await kv.get('market:prices');
    
    if (cachedPrices) {
      return c.json(cachedPrices);
    }

    // Mock market data
    const crops = ['Wheat', 'Rice', 'Corn', 'Tomatoes', 'Onions', 'Potatoes'];
    const marketPrices = crops.slice(0, 3).map(crop => {
      const basePrice = crop === 'Wheat' ? 2000 : crop === 'Rice' ? 1800 : 3000;
      const variation = Math.floor(Math.random() * 400) - 200;
      const currentPrice = basePrice + variation;
      const previousPrice = currentPrice - (Math.floor(Math.random() * 200) - 100);
      
      return {
        crop,
        currentPrice,
        previousPrice,
        change: currentPrice - previousPrice,
        changePercent: ((currentPrice - previousPrice) / previousPrice * 100).toFixed(1),
        unit: 'quintal',
        market: ['Pune Mandi', 'Mumbai APMC', 'Local Market'][Math.floor(Math.random() * 3)],
        lastUpdated: new Date().toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: true 
        }),
        volume: Math.floor(Math.random() * 1000) + 500,
        forecast: ['bullish', 'bearish', 'stable'][Math.floor(Math.random() * 3)]
      };
    });

    await kv.set('market:prices', marketPrices);
    return c.json(marketPrices);
  } catch (error) {
    console.log('Market prices error:', error);
    return c.json({ error: 'Failed to fetch market prices' }, 500);
  }
});

// AI Recommendations endpoint
app.get("/make-server-8c17ee28/recommendations/:farmId", async (c) => {
  try {
    const farmId = c.req.param("farmId");
    const cachedRecs = await kv.get(`recommendations:${farmId}`);
    
    if (cachedRecs) {
      return c.json(cachedRecs);
    }

    // Mock AI recommendations
    const recommendationTypes = ['irrigation', 'crop', 'fertilizer', 'pest', 'harvest'];
    const priorities = ['high', 'medium', 'low'];
    const statuses = ['pending', 'in-progress', 'completed'];
    
    const recommendations = [
      {
        id: '1',
        type: 'irrigation',
        title: 'Optimize Irrigation Schedule',
        description: 'Based on soil moisture data and weather forecast, adjust watering times for better water conservation.',
        confidence: Math.floor(Math.random() * 20) + 80, // 80-100%
        priority: 'high',
        timeframe: 'Next 2 days',
        expectedBenefit: '+15% water efficiency',
        status: 'pending'
      },
      {
        id: '2',
        type: 'crop',
        title: 'Corn Planting Recommendation',
        description: 'Optimal conditions detected for corn planting in the east field. Soil temperature and moisture are ideal.',
        confidence: Math.floor(Math.random() * 20) + 70,
        priority: priorities[Math.floor(Math.random() * 3)],
        timeframe: 'This week',
        expectedBenefit: '+12% yield potential',
        status: statuses[Math.floor(Math.random() * 3)]
      },
      {
        id: '3',
        type: 'fertilizer',
        title: 'Nitrogen Application',
        description: 'Wheat crops showing nitrogen deficiency signs. Apply balanced NPK fertilizer for optimal growth.',
        confidence: Math.floor(Math.random() * 30) + 60,
        priority: priorities[Math.floor(Math.random() * 3)],
        timeframe: 'Within 5 days',
        expectedBenefit: '+8% crop health',
        status: 'pending'
      }
    ];

    await kv.set(`recommendations:${farmId}`, recommendations);
    return c.json(recommendations);
  } catch (error) {
    console.log('Recommendations error:', error);
    return c.json({ error: 'Failed to fetch recommendations' }, 500);
  }
});

// Field data endpoint
app.get("/make-server-8c17ee28/fields/:farmId", async (c) => {
  try {
    const farmId = c.req.param("farmId");
    const cachedFields = await kv.get(`fields:${farmId}`);
    
    if (cachedFields) {
      return c.json(cachedFields);
    }

    // Mock field data
    const crops = ['Wheat', 'Rice', 'Corn', 'Tomatoes', 'Onions'];
    const statuses = ['healthy', 'attention', 'critical'];
    
    const fields = [
      {
        id: '1',
        name: 'North Field A',
        crop: crops[Math.floor(Math.random() * crops.length)],
        area: parseFloat((Math.random() * 10 + 5).toFixed(1)), // 5-15 hectares
        status: statuses[Math.floor(Math.random() * 3)],
        soilMoisture: Math.floor(Math.random() * 60) + 20, // 20-80%
        temperature: Math.floor(Math.random() * 15) + 25, // 25-40°C
        ndvi: parseFloat((Math.random() * 0.5 + 0.4).toFixed(2)), // 0.4-0.9
        lastUpdated: '2 hours ago'
      },
      {
        id: '2',
        name: 'South Field B',
        crop: crops[Math.floor(Math.random() * crops.length)],
        area: parseFloat((Math.random() * 15 + 10).toFixed(1)),
        status: statuses[Math.floor(Math.random() * 3)],
        soilMoisture: Math.floor(Math.random() * 60) + 20,
        temperature: Math.floor(Math.random() * 15) + 25,
        ndvi: parseFloat((Math.random() * 0.5 + 0.4).toFixed(2)),
        lastUpdated: '1 hour ago'
      },
      {
        id: '3',
        name: 'East Field C',
        crop: crops[Math.floor(Math.random() * crops.length)],
        area: parseFloat((Math.random() * 12 + 8).toFixed(1)),
        status: statuses[Math.floor(Math.random() * 3)],
        soilMoisture: Math.floor(Math.random() * 60) + 20,
        temperature: Math.floor(Math.random() * 15) + 25,
        ndvi: parseFloat((Math.random() * 0.5 + 0.4).toFixed(2)),
        lastUpdated: '30 minutes ago'
      },
      {
        id: '4',
        name: 'West Field D',
        crop: crops[Math.floor(Math.random() * crops.length)],
        area: parseFloat((Math.random() * 8 + 6).toFixed(1)),
        status: statuses[Math.floor(Math.random() * 3)],
        soilMoisture: Math.floor(Math.random() * 60) + 20,
        temperature: Math.floor(Math.random() * 15) + 25,
        ndvi: parseFloat((Math.random() * 0.5 + 0.4).toFixed(2)),
        lastUpdated: '15 minutes ago'
      }
    ];

    await kv.set(`fields:${farmId}`, fields);
    return c.json(fields);
  } catch (error) {
    console.log('Fields error:', error);
    return c.json({ error: 'Failed to fetch field data' }, 500);
  }
});

// Analytics data endpoint
app.get("/make-server-8c17ee28/analytics/:farmId", async (c) => {
  try {
    const farmId = c.req.param("farmId");
    const cachedAnalytics = await kv.get(`analytics:${farmId}`);
    
    if (cachedAnalytics) {
      return c.json(cachedAnalytics);
    }

    // Mock analytics data
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const yieldData = months.map(month => ({
      month,
      wheat: Math.floor(Math.random() * 30) + 40,
      rice: Math.floor(Math.random() * 25) + 35,
      corn: Math.floor(Math.random() * 35) + 45
    }));

    const revenueData = months.map((month, index) => {
      const baseRevenue = 80000 + (index * 5000);
      const revenue = baseRevenue + Math.floor(Math.random() * 20000);
      const expenses = Math.floor(revenue * 0.5) + Math.floor(Math.random() * 10000);
      return {
        month,
        revenue,
        expenses,
        profit: revenue - expenses
      };
    });

    const analytics = {
      yieldData,
      revenueData,
      cropDistribution: [
        { name: 'Wheat', value: 40, color: '#8884d8' },
        { name: 'Rice', value: 25, color: '#82ca9d' },
        { name: 'Corn', value: 20, color: '#ffc658' },
        { name: 'Vegetables', value: 15, color: '#ff7300' }
      ],
      weatherImpact: months.map(month => ({
        date: `2024-${String(months.indexOf(month) + 1).padStart(2, '0')}`,
        temperature: Math.floor(Math.random() * 15) + 22,
        rainfall: Math.floor(Math.random() * 50) + 15,
        yield: Math.floor(Math.random() * 25) + 70
      }))
    };

    await kv.set(`analytics:${farmId}`, analytics);
    return c.json(analytics);
  } catch (error) {
    console.log('Analytics error:', error);
    return c.json({ error: 'Failed to fetch analytics data' }, 500);
  }
});

// Disease detection endpoint
app.post("/make-server-8c17ee28/detect-disease", async (c) => {
  try {
    const body = await c.req.json();
    const { imageData, fieldId } = body;

    // Mock AI disease detection
    const diseases = [
      'Tomato Blight',
      'Wheat Rust',
      'Rice Blast',
      'Corn Smut',
      'Healthy Crop'
    ];
    
    const severities = ['low', 'medium', 'high'];
    const disease = diseases[Math.floor(Math.random() * diseases.length)];
    const isHealthy = disease === 'Healthy Crop';
    
    const result = {
      disease: isHealthy ? null : disease,
      confidence: Math.floor(Math.random() * 20) + (isHealthy ? 95 : 75),
      severity: isHealthy ? null : severities[Math.floor(Math.random() * 3)],
      treatment: isHealthy ? null : 'Apply copper-based fungicide spray every 7-10 days. Remove affected leaves immediately.',
      prevention: isHealthy ? 'Continue current care practices.' : 'Ensure proper air circulation, avoid overhead watering, and maintain soil drainage.',
      affectedArea: isHealthy ? '0%' : `${Math.floor(Math.random() * 30) + 5}% of leaf surface`,
      isHealthy,
      timestamp: new Date().toISOString()
    };

    // Store detection history
    const historyKey = `disease_history:${fieldId}`;
    const history = await kv.get(historyKey) || [];
    history.unshift(result);
    if (history.length > 10) history.pop(); // Keep last 10 detections
    await kv.set(historyKey, history);

    return c.json(result);
  } catch (error) {
    console.log('Disease detection error:', error);
    return c.json({ error: 'Failed to process disease detection' }, 500);
  }
});

// Voice command processing endpoint
app.post("/make-server-8c17ee28/voice-command", async (c) => {
  try {
    const body = await c.req.json();
    const { command, farmId } = body;

    // Mock AI voice processing
    let response = '';
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('weather')) {
      response = 'Based on satellite data and meteorological analysis, expect partly cloudy weather with 60% chance of rain in the next 3 days. Temperature will range from 24°C to 32°C. Perfect conditions for your crops!';
    } else if (lowerCommand.includes('water') || lowerCommand.includes('irrigation')) {
      response = 'Your soil moisture levels are optimal. I recommend light watering tomorrow morning around 6 AM. Avoid watering during midday to prevent evaporation loss.';
    } else if (lowerCommand.includes('price') || lowerCommand.includes('market')) {
      response = 'Current wheat prices are ₹2,150 per quintal, up 3.2% from yesterday. Market forecast shows continued bullish trend for the next 2 weeks. Good time to sell if you have stock ready.';
    } else if (lowerCommand.includes('harvest')) {
      response = 'Your corn crop is 85% mature. Based on growth patterns and weather conditions, optimal harvest time is in 10-12 days. I\'ll send you a reminder notification.';
    } else if (lowerCommand.includes('disease')) {
      response = 'No disease detected in your monitored fields. However, keep an eye on Field Section B - humidity levels are slightly elevated which could promote fungal growth.';
    } else {
      response = 'I understand your question. Let me analyze the current data and provide you with the most accurate recommendation based on real-time field conditions and AI predictions.';
    }

    // Store conversation history
    const conversationKey = `conversations:${farmId}`;
    const conversation = await kv.get(conversationKey) || [];
    conversation.unshift({
      id: Date.now().toString(),
      type: 'user',
      content: command,
      timestamp: new Date().toISOString()
    });
    conversation.unshift({
      id: (Date.now() + 1).toString(),
      type: 'ai',
      content: response,
      timestamp: new Date().toISOString()
    });
    
    if (conversation.length > 20) conversation.splice(20); // Keep last 20 messages
    await kv.set(conversationKey, conversation);

    return c.json({ response, timestamp: new Date().toISOString() });
  } catch (error) {
    console.log('Voice command error:', error);
    return c.json({ error: 'Failed to process voice command' }, 500);
  }
});

Deno.serve(app.fetch);