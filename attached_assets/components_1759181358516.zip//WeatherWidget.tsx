import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Skeleton } from './ui/skeleton';
import { 
  Cloud, 
  Sun, 
  CloudRain,
  Thermometer,
  Droplets,
  Wind,
  TrendingUp
} from 'lucide-react';

interface WeatherForecast {
  day: string;
  high: number;
  low: number;
  icon: string;
}

interface WeatherData {
  temperature: number;
  humidity: number;
  condition: string;
  forecast: WeatherForecast[];
}

interface WeatherWidgetProps {
  data?: WeatherData;
  isLoading?: boolean;
}

export function WeatherWidget({ data, isLoading }: WeatherWidgetProps) {
  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 h-full">
        <CardHeader>
          <Skeleton className="h-6 w-40" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  const defaultData: WeatherData = {
    temperature: 32,
    humidity: 65,
    condition: 'Clear sky',
    forecast: [
      { day: 'Today', high: 32, low: 24, icon: '☀️' },
      { day: 'Tomorrow', high: 30, low: 22, icon: '⛅' },
      { day: 'Thu', high: 28, low: 20, icon: '🌧️' }
    ]
  };

  const weather = data || defaultData;

  const getWeatherIcon = (condition: string) => {
    if (condition.toLowerCase().includes('clear') || condition.toLowerCase().includes('sunny')) {
      return <Sun className="w-8 h-8 text-yellow-400" />;
    } else if (condition.toLowerCase().includes('cloud')) {
      return <Cloud className="w-8 h-8 text-slate-400" />;
    } else if (condition.toLowerCase().includes('rain')) {
      return <CloudRain className="w-8 h-8 text-blue-400" />;
    }
    return <Sun className="w-8 h-8 text-yellow-400" />;
  };

  return (
    <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600 h-full">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-white">
          <div className="p-2 bg-yellow-500/20 rounded-lg">
            <Sun className="w-5 h-5 text-yellow-400" />
          </div>
          Weather & Market
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Current Weather */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-lg border border-yellow-500/20"
        >
          <div className="flex items-center justify-center mb-3">
            {getWeatherIcon(weather.condition)}
          </div>
          <div className="space-y-1">
            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 mb-2">
              Today
            </Badge>
            <div className="text-3xl font-bold text-white">{weather.temperature}°C</div>
            <p className="text-slate-300">{weather.condition}, {weather.humidity}% humidity</p>
            <p className="text-xs text-blue-400">Good for field work</p>
          </div>
        </motion.div>

        {/* Forecast */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-3"
        >
          <h4 className="text-sm font-medium text-slate-300">3-Day Forecast</h4>
          <div className="grid grid-cols-3 gap-2">
            {weather.forecast.map((day, index) => (
              <motion.div
                key={day.day}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className="text-center p-3 bg-slate-700/30 rounded-lg border border-slate-600"
              >
                <p className="text-xs text-slate-400 mb-1">{day.day}</p>
                <div className="text-lg mb-1">{day.icon}</div>
                <div className="text-sm">
                  <span className="text-white font-medium">{day.high}°</span>
                  <span className="text-slate-400 mx-1">/</span>
                  <span className="text-slate-400">{day.low}°</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Market Conditions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <h4 className="text-sm font-medium text-slate-300">Market</h4>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              +5%
            </Badge>
          </div>
          
          <div className="p-3 bg-slate-700/30 rounded-lg border border-slate-600">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-300">Wheat: ₹2,150/kg</span>
                <span className="text-green-400">↗ +5%</span>
              </div>
              <p className="text-xs text-slate-400">Best time to sell</p>
            </div>
          </div>
        </motion.div>

        {/* Weather Alerts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20"
        >
          <div className="flex items-center gap-2 mb-2">
            <CloudRain className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-medium text-blue-400">Weather Alert</span>
          </div>
          <p className="text-xs text-slate-300">
            Light rainfall expected in 2 days. Good for soil moisture. Consider postponing harvest.
          </p>
        </motion.div>

        {/* Environmental Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-3 gap-2 text-xs"
        >
          <div className="text-center p-2 bg-slate-700/20 rounded">
            <Thermometer className="w-4 h-4 text-red-400 mx-auto mb-1" />
            <p className="text-slate-300">Heat Index</p>
            <p className="text-red-400">Moderate</p>
          </div>
          
          <div className="text-center p-2 bg-slate-700/20 rounded">
            <Droplets className="w-4 h-4 text-blue-400 mx-auto mb-1" />
            <p className="text-slate-300">Humidity</p>
            <p className="text-blue-400">{weather.humidity}%</p>
          </div>
          
          <div className="text-center p-2 bg-slate-700/20 rounded">
            <Wind className="w-4 h-4 text-green-400 mx-auto mb-1" />
            <p className="text-slate-300">Wind</p>
            <p className="text-green-400">12 km/h</p>
          </div>
        </motion.div>
      </CardContent>
    </Card>
  );
}