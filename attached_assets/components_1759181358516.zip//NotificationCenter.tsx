import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { 
  Bell, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  X,
  Clock,
  TrendingUp,
  CloudRain,
  Bug,
  Satellite,
  BarChart3,
  Settings
} from 'lucide-react';

interface Notification {
  id: string;
  type: 'warning' | 'success' | 'info' | 'error';
  title: string;
  message: string;
  timestamp: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  read: boolean;
  category: 'weather' | 'disease' | 'market' | 'system' | 'recommendation';
}

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onNotificationClick: (notification: Notification) => void;
}

export function NotificationCenter({ isOpen, onClose, onNotificationClick }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [filter, setFilter] = useState<'all' | 'unread' | 'weather' | 'disease' | 'market'>('all');

  // Initialize notifications
  useEffect(() => {
    const initialNotifications: Notification[] = [
      {
        id: '1',
        type: 'warning',
        title: 'Weather Alert',
        message: 'Heavy rainfall expected in your area. Consider harvesting soon.',
        timestamp: '2 hours ago',
        read: false,
        category: 'weather',
        action: {
          label: 'View Weather',
          onClick: () => console.log('Opening weather section')
        }
      },
      {
        id: '2',
        type: 'error',
        title: 'Disease Detection',
        message: 'Potential leaf blight detected in North Field. Immediate action recommended.',
        timestamp: '3 hours ago',
        read: false,
        category: 'disease',
        action: {
          label: 'View Details',
          onClick: () => console.log('Opening disease scanner')
        }
      },
      {
        id: '3',
        type: 'success',
        title: 'Market Opportunity',
        message: 'Wheat prices increased by 8%. Good time to sell your harvest.',
        timestamp: '5 hours ago',
        read: false,
        category: 'market',
        action: {
          label: 'View Market',
          onClick: () => console.log('Opening market analysis')
        }
      },
      {
        id: '4',
        type: 'info',
        title: 'Satellite Update',
        message: 'New NDVI data available for your fields. Growth index improved by 12%.',
        timestamp: '1 day ago',
        read: true,
        category: 'system'
      },
      {
        id: '5',
        type: 'success',
        title: 'AI Recommendation',
        message: 'Based on current conditions, pearl millet is recommended for next season.',
        timestamp: '1 day ago',
        read: true,
        category: 'recommendation',
        action: {
          label: 'View Recommendations',
          onClick: () => console.log('Opening AI recommendations')
        }
      },
      {
        id: '6',
        type: 'info',
        title: 'System Update',
        message: 'Voice assistant now supports Punjabi language.',
        timestamp: '2 days ago',
        read: true,
        category: 'system'
      }
    ];
    setNotifications(initialNotifications);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const getIcon = (type: string, category: string) => {
    if (category === 'weather') return CloudRain;
    if (category === 'disease') return Bug;
    if (category === 'market') return TrendingUp;
    if (category === 'system') return Satellite;
    if (category === 'recommendation') return BarChart3;
    
    switch (type) {
      case 'warning': return AlertTriangle;
      case 'success': return CheckCircle;
      case 'error': return AlertTriangle;
      case 'info': return Info;
      default: return Info;
    }
  };

  const getColorClass = (type: string) => {
    switch (type) {
      case 'warning': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30';
      case 'success': return 'text-green-400 bg-green-500/20 border-green-500/30';
      case 'error': return 'text-red-400 bg-red-500/20 border-red-500/30';
      case 'info': return 'text-blue-400 bg-blue-500/20 border-blue-500/30';
      default: return 'text-slate-400 bg-slate-500/20 border-slate-500/30';
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true }))
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !notification.read;
    return notification.category === filter;
  });

  const filterOptions = [
    { value: 'all', label: 'All', count: notifications.length },
    { value: 'unread', label: 'Unread', count: unreadCount },
    { value: 'weather', label: 'Weather', count: notifications.filter(n => n.category === 'weather').length },
    { value: 'disease', label: 'Disease', count: notifications.filter(n => n.category === 'disease').length },
    { value: 'market', label: 'Market', count: notifications.filter(n => n.category === 'market').length }
  ];

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: -20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: -20 }}
      className="fixed top-16 right-4 z-50 w-96 max-h-[80vh]"
    >
      <Card className="bg-slate-800/95 border-slate-600 backdrop-blur-sm shadow-2xl">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-white">
              <Bell className="w-5 h-5 text-blue-400" />
              Notifications
              {unreadCount > 0 && (
                <Badge className="bg-red-500 text-white ml-2">
                  {unreadCount}
                </Badge>
              )}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
                onClick={markAllAsRead}
                disabled={unreadCount === 0}
              >
                Mark all read
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="text-slate-400 hover:text-white hover:bg-slate-700"
                onClick={onClose}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {/* Filter Tabs */}
          <div className="flex gap-1 mt-4">
            {filterOptions.map(option => (
              <Button
                key={option.value}
                size="sm"
                variant={filter === option.value ? 'default' : 'ghost'}
                className={`text-xs ${
                  filter === option.value 
                    ? 'bg-blue-600 text-white' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
                onClick={() => setFilter(option.value as any)}
              >
                {option.label}
                {option.count > 0 && (
                  <span className="ml-1 bg-slate-600 text-white text-xs px-1.5 py-0.5 rounded-full">
                    {option.count}
                  </span>
                )}
              </Button>
            ))}
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <ScrollArea className="h-96">
            <div className="space-y-2 p-4">
              <AnimatePresence>
                {filteredNotifications.length > 0 ? (
                  filteredNotifications.map((notification, index) => {
                    const IconComponent = getIcon(notification.type, notification.category);
                    
                    return (
                      <motion.div
                        key={notification.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ delay: index * 0.05 }}
                        className={`p-4 rounded-lg border cursor-pointer transition-all hover:bg-slate-700/50 ${
                          notification.read 
                            ? 'bg-slate-700/20 border-slate-600' 
                            : 'bg-slate-700/40 border-slate-500'
                        }`}
                        onClick={() => {
                          markAsRead(notification.id);
                          onNotificationClick(notification);
                        }}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg border ${getColorClass(notification.type)}`}>
                            <IconComponent className="w-4 h-4" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <h4 className={`font-medium ${notification.read ? 'text-slate-300' : 'text-white'}`}>
                                {notification.title}
                              </h4>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-slate-400 hover:text-red-400 hover:bg-red-500/10 p-1 h-auto"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  deleteNotification(notification.id);
                                }}
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                            
                            <p className={`text-sm mt-1 ${notification.read ? 'text-slate-400' : 'text-slate-300'}`}>
                              {notification.message}
                            </p>
                            
                            <div className="flex items-center justify-between mt-3">
                              <div className="flex items-center gap-2 text-xs text-slate-500">
                                <Clock className="w-3 h-3" />
                                {notification.timestamp}
                              </div>
                              
                              {notification.action && (
                                <Button
                                  size="sm"
                                  className={`text-xs h-6 px-3 ${getColorClass(notification.type).replace('text-', 'bg-').replace('bg-', 'bg-').replace('/20', '/30')} hover:opacity-80`}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    notification.action?.onClick();
                                    markAsRead(notification.id);
                                  }}
                                >
                                  {notification.action.label}
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-8"
                  >
                    <Bell className="w-12 h-12 text-slate-500 mx-auto mb-3" />
                    <p className="text-slate-400">No notifications found</p>
                    <p className="text-slate-500 text-sm mt-1">
                      {filter === 'unread' ? 'All caught up!' : 'Try changing the filter'}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </ScrollArea>
        </CardContent>

        {/* Settings Footer */}
        <div className="border-t border-slate-600 p-4">
          <Button
            size="sm"
            variant="ghost"
            className="w-full text-slate-400 hover:text-white hover:bg-slate-700"
            onClick={() => console.log('Opening notification settings')}
          >
            <Settings className="w-4 h-4 mr-2" />
            Notification Settings
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}