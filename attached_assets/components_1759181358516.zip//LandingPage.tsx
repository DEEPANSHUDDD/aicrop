import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Brain, 
  Satellite, 
  Camera, 
  Mic, 
  WifiOff,
  TrendingUp,
  Users,
  Shield,
  Target,
  Play,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Globe,
  BarChart3,
  Zap,
  Activity,
  MessageSquare
} from 'lucide-react';

interface LandingPageProps {
  onEnterDashboard: () => void;
  onStartDemo: (demoType: string) => void;
}

export function LandingPage({ onEnterDashboard, onStartDemo }: LandingPageProps) {
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);

  const mainFeatures = [
    {
      id: 'ai-recommendations',
      icon: Brain,
      title: 'AI Crop Recommendations',
      description: 'Get personalized crop suggestions based on soil, weather, and market data',
      color: 'blue',
      stats: '95% Accuracy',
      action: () => onStartDemo('ai-recommendations')
    },
    {
      id: 'disease-detection',
      icon: Camera,
      title: 'Disease Detection',
      description: 'Instant plant disease identification using computer vision',
      color: 'red',
      stats: '50+ Diseases',
      action: () => onStartDemo('disease-detection')
    },
    {
      id: 'voice-assistant',
      icon: Mic,
      title: 'Voice Assistant',
      description: 'Multilingual voice interface supporting 8+ Indian languages',
      color: 'purple',
      stats: '8+ Languages',
      action: () => onStartDemo('voice-assistant')
    },
    {
      id: 'satellite-monitoring',
      icon: Satellite,
      title: 'Satellite Monitoring',
      description: 'Real-time field monitoring with NDVI analysis',
      color: 'green',
      stats: 'Live Data',
      action: () => onStartDemo('satellite-monitoring')
    },
    {
      id: 'offline-mode',
      icon: WifiOff,
      title: 'Offline Mode',
      description: 'Full functionality without internet connection',
      color: 'orange',
      stats: '100% Offline',
      action: () => onStartDemo('offline-mode')
    },
    {
      id: 'market-analysis',
      icon: TrendingUp,
      title: 'Market Analysis',
      description: 'Real-time price trends and profit optimization',
      color: 'cyan',
      stats: 'Live Prices',
      action: () => onStartDemo('market-analysis')
    }
  ];

  const stats = [
    { label: 'Active Farmers', value: '10,000+', icon: Users, color: 'blue' },
    { label: 'Accuracy Rate', value: '95%', icon: Target, color: 'green' },
    { label: 'Uptime', value: '99.9%', icon: Shield, color: 'purple' },
    { label: 'Languages', value: '8+', icon: Globe, color: 'orange' }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'from-blue-600 to-blue-800 border-blue-500/30 text-blue-400',
      red: 'from-red-600 to-red-800 border-red-500/30 text-red-400',
      purple: 'from-purple-600 to-purple-800 border-purple-500/30 text-purple-400',
      green: 'from-green-600 to-green-800 border-green-500/30 text-green-400',
      orange: 'from-orange-600 to-orange-800 border-orange-500/30 text-orange-400',
      cyan: 'from-cyan-600 to-cyan-800 border-cyan-500/30 text-cyan-400'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const handleVideoPlay = () => {
    setIsVideoPlaying(true);
    // Simulate video playback
    setTimeout(() => {
      setIsVideoPlaying(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
          <div className="absolute top-3/4 left-3/4 w-96 h-96 bg-green-500/10 rounded-full blur-3xl" />
        </div>
        
        <div className="relative container mx-auto px-4 py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            {/* Logo and Title */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="mb-8"
            >
              <div className="inline-flex items-center gap-3 mb-6">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl">
                  <Brain className="w-12 h-12 text-white" />
                </div>
                <div className="text-left">
                  <h1 className="text-4xl lg:text-6xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                    AI CropAdvisor
                  </h1>
                  <p className="text-blue-200 text-lg">Smart India Hackathon 2025</p>
                </div>
              </div>
            </motion.div>

            {/* Main Tagline */}
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-2xl lg:text-3xl font-medium text-white mb-6 leading-relaxed"
            >
              Empowering Indian farmers with AI-driven agriculture solutions
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto"
            >
              Comprehensive platform featuring crop recommendations, disease detection, 
              multilingual voice assistance, and offline capabilities tailored for Indian agriculture.
            </motion.p>

            {/* Key Features Tags */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="flex flex-wrap justify-center gap-3 mb-10"
            >
              {[
                'AI/ML Powered',
                'Real-time Satellite Data',
                '8+ Indian Languages',
                'Offline Ready',
                'SIH 2025 Innovation'
              ].map((tag, index) => (
                <Badge
                  key={index}
                  className="bg-white/10 text-white border-white/20 px-4 py-2 hover:bg-white/20 transition-all cursor-pointer"
                  onClick={() => console.log(`Clicked tag: ${tag}`)}
                >
                  {tag}
                </Badge>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.0 }}
              className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg"
                onClick={onEnterDashboard}
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Enter Full Platform
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg"
                onClick={handleVideoPlay}
              >
                {isVideoPlaying ? (
                  <>
                    <Activity className="w-5 h-5 mr-2 animate-spin" />
                    Playing Demo...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Watch Demo Video
                  </>
                )}
              </Button>
            </motion.div>

            {/* Video Demo Placeholder */}
            {isVideoPlaying && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="max-w-4xl mx-auto mb-12"
              >
                <div className="relative aspect-video bg-slate-800 rounded-2xl border border-slate-600 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-purple-600/20 flex items-center justify-center">
                    <div className="text-center">
                      <Activity className="w-16 h-16 text-white animate-spin mx-auto mb-4" />
                      <p className="text-white text-xl">AI CropAdvisor Demo</p>
                      <p className="text-blue-200">Showcasing all features...</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>

          {/* Stats Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.3 + index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="text-center p-6 bg-white/5 border border-white/10 rounded-xl backdrop-blur-sm cursor-pointer"
                onClick={() => console.log(`Clicked stat: ${stat.label}`)}
              >
                <stat.icon className={`w-8 h-8 mx-auto mb-3 ${getColorClasses(stat.color).split(' ')[2]}`} />
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-blue-200">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Comprehensive AI Agriculture Platform
            </h2>
            <p className="text-lg text-blue-100 max-w-2xl mx-auto">
              Experience cutting-edge technology designed specifically for Indian farmers
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mainFeatures.map((feature, index) => (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className={`relative overflow-hidden cursor-pointer transition-all duration-300 ${
                  activeFeature === feature.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => {
                  setActiveFeature(feature.id);
                  feature.action();
                }}
                onMouseEnter={() => setActiveFeature(feature.id)}
                onMouseLeave={() => setActiveFeature(null)}
              >
                <Card className={`h-full bg-gradient-to-br ${getColorClasses(feature.color).split(' ').slice(0, 2).join(' ')}/10 border-${feature.color}-500/30 hover:bg-gradient-to-br hover:${getColorClasses(feature.color).split(' ').slice(0, 2).join(' ')}/20`}>
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 bg-${feature.color}-500/20 rounded-lg`}>
                        <feature.icon className={`w-8 h-8 ${getColorClasses(feature.color).split(' ')[2]}`} />
                      </div>
                      <Badge className={`bg-${feature.color}-500/20 ${getColorClasses(feature.color).split(' ')[2]} border-${feature.color}-500/30`}>
                        {feature.stats}
                      </Badge>
                    </div>
                    <CardTitle className="text-white text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-slate-300 mb-6">{feature.description}</p>
                    <Button
                      className={`w-full bg-gradient-to-r ${getColorClasses(feature.color).split(' ').slice(0, 2).join(' ')} hover:opacity-90 text-white`}
                      onClick={(e) => {
                        e.stopPropagation();
                        feature.action();
                      }}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Try Demo
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Preview */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Built with Cutting-Edge Technology
            </h2>
            <p className="text-lg text-blue-100 max-w-2xl mx-auto mb-8">
              Leveraging the latest in AI, machine learning, and satellite technology
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            {[
              { name: 'TensorFlow', description: 'AI/ML Framework', icon: Brain },
              { name: 'Sentinel-2', description: 'Satellite Data', icon: Satellite },
              { name: 'React Native', description: 'Mobile Platform', icon: MessageSquare },
              { name: 'Voice API', description: 'Speech Recognition', icon: Mic }
            ].map((tech, index) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="text-center p-6 bg-slate-800/50 border border-slate-600 rounded-xl cursor-pointer hover:bg-slate-700/50 transition-all"
                onClick={() => console.log(`Clicked tech: ${tech.name}`)}
              >
                <tech.icon className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">{tech.name}</h3>
                <p className="text-slate-400 text-sm">{tech.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-4"
              onClick={onEnterDashboard}
            >
              <Zap className="w-5 h-5 mr-2" />
              Explore Full Platform
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10" />
        <div className="relative container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Ready to Transform Your Farming?
            </h2>
            <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
              Join thousands of farmers already using AI CropAdvisor to increase yields and reduce costs
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg"
                onClick={onEnterDashboard}
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Start Your Journey
              </Button>
              
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg"
                onClick={() => onStartDemo('overview')}
              >
                <BarChart3 className="w-5 h-5 mr-2" />
                View Live Demo
              </Button>
            </div>

            <div className="flex items-center justify-center gap-8 mt-12 text-sm text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Free to Use
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Offline Capable
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                24/7 Support
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}