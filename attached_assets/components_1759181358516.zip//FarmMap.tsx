import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Map, 
  Satellite, 
  Layers, 
  MapPin, 
  Thermometer,
  Droplets,
  Zap,
  AlertTriangle,
  CheckCircle,
  Activity,
  Target
} from 'lucide-react';

interface FieldData {
  id: string;
  name: string;
  crop: string;
  area: number | string;
  status: 'healthy' | 'attention' | 'critical';
  soilMoisture: number;
  temperature: number;
  ndvi: number | string; // Normalized Difference Vegetation Index
  lastUpdated: string;
}

interface FarmMapProps {
  fields?: FieldData[];
  expanded?: boolean;
}

// Default field data for demo
const defaultFields: FieldData[] = [
  {
    id: '1',
    name: 'North Field',
    crop: 'Wheat',
    area: 15.2,
    status: 'healthy',
    soilMoisture: 65,
    temperature: 28,
    ndvi: 0.78,
    lastUpdated: '2 hours ago'
  },
  {
    id: '2',
    name: 'South Field',
    crop: 'Rice',
    area: 12.8,
    status: 'attention',
    soilMoisture: 45,
    temperature: 32,
    ndvi: 0.65,
    lastUpdated: '1 hour ago'
  },
  {
    id: '3',
    name: 'East Field',
    crop: 'Corn',
    area: 18.5,
    status: 'healthy',
    soilMoisture: 58,
    temperature: 30,
    ndvi: 0.72,
    lastUpdated: '30 min ago'
  },
  {
    id: '4',
    name: 'West Field',
    crop: 'Soybean',
    area: 8.2,
    status: 'healthy',
    soilMoisture: 72,
    temperature: 26,
    ndvi: 0.81,
    lastUpdated: '45 min ago'
  }
];

export function FarmMap({ fields, expanded = false }: FarmMapProps) {
  const fieldData = fields || defaultFields;
  const [selectedField, setSelectedField] = useState<FieldData | null>(null);
  const [mapView, setMapView] = useState<'satellite' | 'ndvi' | 'moisture' | 'temperature'>('satellite');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-green-500';
      case 'attention': return 'bg-yellow-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return CheckCircle;
      case 'attention': return AlertTriangle;
      case 'critical': return AlertTriangle;
      default: return MapPin;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={expanded ? "col-span-full" : ""}
    >
      <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-white">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Map className="w-5 h-5 text-blue-400" />
              </div>
              Satellite Farm Monitoring
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                <Satellite className="w-3 h-3 mr-1" />
                Live Satellite
              </Badge>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <Activity className="w-3 h-3 mr-1" />
                Real-time
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={mapView} onValueChange={(value) => setMapView(value as any)} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-slate-700/50 border border-slate-600">
              <TabsTrigger value="satellite" className="flex items-center gap-2 data-[state=active]:bg-blue-600">
                <Satellite className="w-4 h-4" />
                Satellite
              </TabsTrigger>
              <TabsTrigger value="ndvi" className="flex items-center gap-2 data-[state=active]:bg-green-600">
                <Layers className="w-4 h-4" />
                NDVI
              </TabsTrigger>
              <TabsTrigger value="moisture" className="flex items-center gap-2 data-[state=active]:bg-cyan-600">
                <Droplets className="w-4 h-4" />
                Moisture
              </TabsTrigger>
              <TabsTrigger value="temperature" className="flex items-center gap-2 data-[state=active]:bg-red-600">
                <Thermometer className="w-4 h-4" />
                Temperature
              </TabsTrigger>
            </TabsList>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Map Visualization */}
              <div className="lg:col-span-2">
                <TabsContent value="satellite" className="mt-0">
                  <div className="relative h-96 bg-gradient-to-br from-slate-700 to-slate-600 rounded-lg border border-slate-500 overflow-hidden">
                    {/* Mock satellite view with dark theme */}
                    <div className="absolute inset-0 bg-gradient-to-br from-green-400/20 to-blue-400/20">
                      {/* Field boundaries */}
                      {fieldData.map((field, index) => {
                        const positions = [
                          { top: '15%', left: '20%', size: 'w-24 h-16' },
                          { top: '45%', left: '60%', size: 'w-32 h-20' },
                          { top: '65%', left: '15%', size: 'w-28 h-18' },
                          { top: '25%', left: '70%', size: 'w-20 h-14' }
                        ];
                        const pos = positions[index];
                        const StatusIcon = getStatusIcon(field.status);
                        
                        return (
                          <div
                            key={field.id}
                            className={`absolute ${pos.size} border-2 border-white/50 rounded cursor-pointer transition-all hover:scale-105 ${getStatusColor(field.status)}/30 hover:${getStatusColor(field.status)}/50`}
                            style={{ top: pos.top, left: pos.left }}
                            onClick={() => setSelectedField(field)}
                          >
                            <div className="absolute -top-2 -right-2">
                              <div className={`w-6 h-6 rounded-full ${getStatusColor(field.status)} flex items-center justify-center`}>
                                <StatusIcon className="w-3 h-3 text-white" />
                              </div>
                            </div>
                            <div className="absolute bottom-1 left-1 right-1">
                              <div className="bg-slate-800/90 rounded px-1 py-0.5">
                                <p className="text-xs font-medium text-white truncate">{field.name}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    
                    {/* Legend */}
                    <div className="absolute top-4 left-4 bg-slate-800/90 rounded-lg p-3 space-y-2 border border-slate-600">
                      <h4 className="font-medium text-sm text-white">Field Status</h4>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs text-slate-300">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span>Healthy</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-300">
                          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                          <span>Needs Attention</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-300">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span>Critical</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="ndvi" className="mt-0">
                  <div className="relative h-96 bg-gradient-to-br from-slate-700 to-slate-600 rounded-lg border border-slate-500 overflow-hidden">
                    <div className="absolute inset-4 bg-slate-800/90 rounded-lg p-4 border border-slate-600">
                      <h4 className="font-medium mb-2 text-white">NDVI Heat Map</h4>
                      <p className="text-sm text-slate-400 mb-4">
                        Vegetation health index based on satellite imagery
                      </p>
                      <div className="space-y-2">
                        {fieldData.map(field => (
                          <div key={field.id} className="flex items-center justify-between p-2 border border-slate-600 rounded bg-slate-700/50">
                            <span className="font-medium text-white">{field.name}</span>
                            <div className="flex items-center gap-2">
                              <div className={`w-4 h-4 rounded ${
                                Number(field.ndvi) > 0.8 ? 'bg-green-500' : 
                                Number(field.ndvi) > 0.6 ? 'bg-yellow-500' : 'bg-red-500'
                              }`}></div>
                              <span className="text-sm font-mono text-slate-300">{Number(field.ndvi).toFixed(2)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="moisture" className="mt-0">
                  <div className="relative h-96 bg-gradient-to-br from-slate-700 to-slate-600 rounded-lg border border-slate-500 overflow-hidden">
                    <div className="absolute inset-4 bg-slate-800/90 rounded-lg p-4 border border-slate-600">
                      <h4 className="font-medium mb-2 text-white">Soil Moisture Levels</h4>
                      <p className="text-sm text-slate-400 mb-4">
                        Real-time soil moisture monitoring across fields
                      </p>
                      <div className="space-y-3">
                        {fieldData.map(field => (
                          <div key={field.id} className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span className="font-medium text-white">{field.name}</span>
                              <span className="text-slate-300">{field.soilMoisture}%</span>
                            </div>
                            <div className="w-full bg-slate-600 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${
                                  field.soilMoisture > 60 ? 'bg-blue-500' :
                                  field.soilMoisture > 40 ? 'bg-yellow-500' : 'bg-red-500'
                                }`}
                                style={{ width: `${field.soilMoisture}%` }}
                              ></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="temperature" className="mt-0">
                  <div className="relative h-96 bg-gradient-to-br from-slate-700 to-slate-600 rounded-lg border border-slate-500 overflow-hidden">
                    <div className="absolute inset-4 bg-slate-800/90 rounded-lg p-4 border border-slate-600">
                      <h4 className="font-medium mb-2 text-white">Temperature Distribution</h4>
                      <p className="text-sm text-slate-400 mb-4">
                        Field temperature monitoring and heat stress analysis
                      </p>
                      <div className="space-y-2">
                        {fieldData.map(field => (
                          <div key={field.id} className="flex items-center justify-between p-2 border border-slate-600 rounded bg-slate-700/50">
                            <span className="font-medium text-white">{field.name}</span>
                            <div className="flex items-center gap-2">
                              <Thermometer className={`w-4 h-4 ${
                                field.temperature > 33 ? 'text-red-400' :
                                field.temperature > 30 ? 'text-orange-400' : 'text-green-400'
                              }`} />
                              <span className="text-sm font-mono text-slate-300">{field.temperature}°C</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </div>

              {/* Field Details */}
              <div className="space-y-4">
                <h3 className="font-medium text-white">Field Overview</h3>
                
                {selectedField ? (
                  <div className="border border-slate-600 rounded-lg p-4 space-y-4 bg-slate-700/30">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-white">{selectedField.name}</h4>
                      <Badge className={
                        selectedField.status === 'healthy' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 
                        selectedField.status === 'attention' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30'
                      }>
                        {selectedField.status}
                      </Badge>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-slate-400">Crop Type</p>
                        <p className="font-medium text-white">{selectedField.crop}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-400">Area</p>
                        <p className="font-medium text-white">{selectedField.area} hectares</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-slate-400">Soil Moisture</p>
                          <p className="font-medium text-white">{selectedField.soilMoisture}%</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Temperature</p>
                          <p className="font-medium text-white">{selectedField.temperature}°C</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">NDVI</p>
                          <p className="font-medium text-white">{selectedField.ndvi}</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Last Updated</p>
                          <p className="font-medium text-white text-xs">{selectedField.lastUpdated}</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700 text-white">View Detailed Report</Button>
                      <Button size="sm" variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700">Schedule Irrigation</Button>
                    </div>
                  </div>
                ) : (
                  <div className="border border-dashed border-slate-600 rounded-lg p-6 text-center bg-slate-700/20">
                    <MapPin className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm text-slate-400">
                      Click on a field in the map to view detailed information
                    </p>
                  </div>
                )}

                {/* Quick Stats */}
                <div className="space-y-3">
                  <h4 className="font-medium text-white">Quick Stats</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="text-center p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                      <p className="text-2xl font-bold text-green-400">3</p>
                      <p className="text-xs text-green-300">Healthy Fields</p>
                    </div>
                    <div className="text-center p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-400">1</p>
                      <p className="text-xs text-yellow-300">Needs Attention</p>
                    </div>
                    <div className="text-center p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                      <p className="text-lg font-bold text-blue-400">54.7</p>
                      <p className="text-xs text-blue-300">Total Hectares</p>
                    </div>
                    <div className="text-center p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                      <p className="text-lg font-bold text-purple-400">0.74</p>
                      <p className="text-xs text-purple-300">Avg NDVI</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </motion.div>
  );
}