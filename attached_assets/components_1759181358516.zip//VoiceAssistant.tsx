import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  Globe,
  Zap,
  CheckCircle,
  Settings,
  Languages
} from 'lucide-react';

interface VoiceAssistantProps {
  isActive: boolean;
  onToggle: (active: boolean) => void;
}

export function VoiceAssistant({ isActive, onToggle }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('Hindi');
  const [voiceLevel, setVoiceLevel] = useState(0);

  useEffect(() => {
    if (isActive) {
      setIsListening(true);
      // Simulate voice level animation
      const interval = setInterval(() => {
        setVoiceLevel(Math.random() * 100);
      }, 100);
      
      return () => clearInterval(interval);
    } else {
      setIsListening(false);
      setVoiceLevel(0);
    }
  }, [isActive]);

  const languages = [
    { code: 'hi', name: 'Hindi', native: 'हिंदी' },
    { code: 'en', name: 'English', native: 'English' },
    { code: 'mr', name: 'Marathi', native: 'मराठी' },
    { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી' },
    { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
    { code: 'te', name: 'Telugu', native: 'తెలుగు' },
    { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ' },
    { code: 'bn', name: 'Bengali', native: 'বাংলা' }
  ];

  return (
    <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/30 h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Languages className="w-5 h-5 text-purple-400" />
            </div>
            Voice Assistant
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
              <Globe className="w-3 h-3 mr-1" />
              8+ Languages
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Voice Activation */}
        <div className="text-center">
          <motion.div
            className="relative mx-auto mb-4"
            style={{ width: 120, height: 120 }}
          >
            {/* Outer Ring */}
            <motion.div
              animate={{
                scale: isActive ? [1, 1.2, 1] : 1,
                opacity: isActive ? [0.3, 0.6, 0.3] : 0.3
              }}
              transition={{
                duration: 2,
                repeat: isActive ? Infinity : 0,
                ease: "easeInOut"
              }}
              className="absolute inset-0 rounded-full border-2 border-purple-500/50"
            />
            
            {/* Middle Ring */}
            <motion.div
              animate={{
                scale: isActive ? [1, 1.1, 1] : 1,
                opacity: isActive ? [0.4, 0.8, 0.4] : 0.4
              }}
              transition={{
                duration: 1.5,
                repeat: isActive ? Infinity : 0,
                ease: "easeInOut",
                delay: 0.2
              }}
              className="absolute inset-2 rounded-full border-2 border-purple-400/60"
            />
            
            {/* Center Button */}
            <Button
              onClick={() => onToggle(!isActive)}
              className={`absolute inset-4 rounded-full ${
                isActive 
                  ? 'bg-gradient-to-br from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700' 
                  : 'bg-slate-700 hover:bg-slate-600'
              } transition-all duration-300`}
            >
              <motion.div
                animate={{ scale: isActive ? [1, 1.1, 1] : 1 }}
                transition={{ duration: 0.5, repeat: isActive ? Infinity : 0 }}
              >
                {isActive ? (
                  <Mic className="w-8 h-8 text-white" />
                ) : (
                  <MicOff className="w-8 h-8 text-slate-400" />
                )}
              </motion.div>
            </Button>
            
            {/* Voice Level Indicator */}
            {isActive && (
              <motion.div
                style={{
                  position: 'absolute',
                  inset: 0,
                  borderRadius: '50%',
                  background: `conic-gradient(from 0deg, rgba(168, 85, 247, 0.3) 0%, rgba(168, 85, 247, 0.6) ${voiceLevel}%, transparent ${voiceLevel}%)`
                }}
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              />
            )}
          </motion.div>

          <p className="text-sm text-slate-300 mb-2">
            {isActive ? 'Tap to speak in your language' : 'Tap to activate voice input'}
          </p>
          
          {isActive && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-purple-400"
            >
              Listening... Speak naturally
            </motion.p>
          )}
        </div>

        {/* Language Selection */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-300">Selected Language:</span>
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
              हिंदी
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
            {languages.slice(0, 6).map((lang) => (
              <Button
                key={lang.code}
                variant={currentLanguage === lang.name ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentLanguage(lang.name)}
                className={`text-xs justify-start ${
                  currentLanguage === lang.name 
                    ? 'bg-purple-600 text-white' 
                    : 'border-slate-600 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span className="mr-2">{lang.native}</span>
                <span className="text-xs opacity-70">{lang.name}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Features */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 p-3 bg-slate-700/30 rounded-lg border border-slate-600">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <div className="flex-1">
              <p className="text-sm text-white">8+ Indian Languages</p>
              <p className="text-xs text-slate-400">Natural language processing</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 p-3 bg-slate-700/30 rounded-lg border border-slate-600">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <div className="flex-1">
              <p className="text-sm text-white">Offline Speech Recognition</p>
              <p className="text-xs text-slate-400">Works without internet</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 p-3 bg-slate-700/30 rounded-lg border border-slate-600">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <div className="flex-1">
              <p className="text-sm text-white">Natural Language Processing</p>
              <p className="text-xs text-slate-400">Understands context and intent</p>
            </div>
          </div>
        </div>

        {/* Demo Status */}
        <div className="text-center">
          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
            <Zap className="w-3 h-3 mr-1" />
            Voice Demo Ready
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}