import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { 
  Brain, 
  Wheat, 
  Calendar, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Target
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Recommendation {
  id: string;
  type: 'crop' | 'irrigation' | 'fertilizer' | 'pest' | 'harvest';
  title: string;
  description: string;
  confidence: number;
  priority: 'high' | 'medium' | 'low';
  timeframe: string;
  expectedBenefit: string;
  status: 'pending' | 'in-progress' | 'completed';
}

interface AIRecommendationsProps {
  recommendations: Recommendation[];
}

const typeIcons = {
  crop: Wheat,
  irrigation: CheckCircle,
  fertilizer: TrendingUp,
  pest: AlertTriangle,
  harvest: Calendar,
};

const priorityColors = {
  high: 'destructive',
  medium: 'default',
  low: 'secondary',
} as const;

const statusIcons = {
  pending: Clock,
  'in-progress': Target,
  completed: CheckCircle,
};

export function AIRecommendations({ recommendations }: AIRecommendationsProps) {
  return (
    <Card className="col-span-full lg:col-span-3">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary" />
          AI-Powered Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations.map((rec) => {
            const TypeIcon = typeIcons[rec.type];
            const StatusIcon = statusIcons[rec.status];
            
            return (
              <div key={rec.id} className="border border-border rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      <TypeIcon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{rec.title}</h4>
                        <Badge variant={priorityColors[rec.priority]} className="text-xs">
                          {rec.priority} priority
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{rec.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <StatusIcon className="w-4 h-4" />
                    <span className="capitalize">{rec.status.replace('-', ' ')}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Confidence</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Progress value={rec.confidence} className="flex-1" />
                      <span className="font-medium">{rec.confidence}%</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Timeframe</p>
                    <p className="font-medium mt-1">{rec.timeframe}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Expected Benefit</p>
                    <p className="font-medium mt-1 text-green-600">{rec.expectedBenefit}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button size="sm" variant="default">
                    Accept
                  </Button>
                  <Button size="sm" variant="outline">
                    More Details
                  </Button>
                  <Button size="sm" variant="ghost">
                    Dismiss
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-3">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1754776403499-52e7acdd45a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBhZ3JpY3VsdHVyZSUyMG1vbml0b3Jpbmd8ZW58MXx8fHwxNzU4ODg2MTAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="AI Analysis"
              className="w-12 h-12 rounded-lg object-cover"
            />
            <div className="flex-1">
              <h4 className="font-medium">AI Analysis Summary</h4>
              <p className="text-sm text-muted-foreground">
                Based on satellite data, weather patterns, and soil analysis, our AI models have generated 
                {recommendations.length} personalized recommendations to optimize your crop yield by an estimated 15-20%.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}