import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Camera, 
  Scan, 
  CheckCircle, 
  AlertTriangle,
  Upload,
  Zap,
  Eye
} from 'lucide-react';

export function DiseaseScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<{
    confidence: number;
    disease: string;
    status: 'healthy' | 'diseased';
  } | null>(null);

  const handleScan = () => {
    setIsScanning(true);
    setScanResult(null);
    
    // Simulate scanning process
    setTimeout(() => {
      setScanResult({
        confidence: 94,
        disease: 'Healthy',
        status: 'healthy'
      });
      setIsScanning(false);
    }, 3000);
  };

  const handleUpload = () => {
    setIsScanning(true);
    setScanResult(null);
    
    // Simulate upload and analysis
    setTimeout(() => {
      setScanResult({
        confidence: 87,
        disease: 'Early Blight Detection',
        status: 'diseased'
      });
      setIsScanning(false);
    }, 2500);
  };

  return (
    <Card className="bg-gradient-to-br from-red-900/20 to-orange-900/20 border-red-500/30 h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <div className="p-2 bg-red-500/20 rounded-lg">
              <Eye className="w-5 h-5 text-red-400" />
            </div>
            Crop Disease Scanner
          </CardTitle>
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
            <Camera className="w-3 h-3 mr-1" />
            AI Vision
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Camera/Upload Area */}
        <div className="relative">
          <div className="aspect-square bg-slate-700/30 rounded-lg border-2 border-dashed border-slate-600 flex items-center justify-center overflow-hidden">
            {isScanning ? (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-center"
              >
                <div className="relative">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full mx-auto mb-4"
                  />
                  <Scan className="w-8 h-8 text-blue-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
                </div>
                <p className="text-sm text-slate-300">Analyzing crop image...</p>
                <Progress value={60} className="mt-2 w-32 mx-auto" />
              </motion.div>
            ) : (
              <div className="text-center p-6">
                <Camera className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-sm text-slate-300 mb-2">Take a photo of your crop</p>
                <p className="text-xs text-slate-400">AI will analyze for diseases</p>
              </div>
            )}
          </div>

          {/* Scan Overlay Effect */}
          {isScanning && (
            <motion.div
              initial={{ top: '0%' }}
              animate={{ top: '100%' }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="absolute left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-80"
            />
          )}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <Button
            onClick={handleScan}
            disabled={isScanning}
            className="bg-pink-600 hover:bg-pink-700 text-white"
          >
            <Camera className="w-4 h-4 mr-2" />
            Scan for Diseases
          </Button>
          <Button
            onClick={handleUpload}
            disabled={isScanning}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Image
          </Button>
        </div>

        {/* Results */}
        {scanResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-300">Last Scan:</span>
              <Badge className={scanResult.status === 'healthy' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
                {scanResult.status === 'healthy' ? 'Healthy ✓' : 'Disease Found'}
              </Badge>
            </div>

            <div className="p-4 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {scanResult.status === 'healthy' ? (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                  )}
                  <span className="font-medium text-white">{scanResult.disease}</span>
                </div>
                <Badge variant="outline" className="text-xs">
                  {scanResult.confidence}% confidence
                </Badge>
              </div>
              
              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span>Confidence:</span>
                  <span className={scanResult.confidence > 90 ? 'text-green-400' : 'text-yellow-400'}>
                    {scanResult.confidence}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Offline Mode:</span>
                  <span className="text-green-400">Available ✓</span>
                </div>
              </div>
              
              <Progress 
                value={scanResult.confidence} 
                className="mt-3" 
              />
            </div>

            {scanResult.status === 'diseased' && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span className="text-sm font-medium text-red-400">Treatment Recommendation</span>
                </div>
                <p className="text-xs text-slate-300">
                  Apply copper-based fungicide. Monitor field daily. Consider crop rotation.
                </p>
              </div>
            )}
          </motion.div>
        )}

        {/* Features */}
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="text-center p-2 bg-slate-700/20 rounded">
            <Zap className="w-4 h-4 text-yellow-400 mx-auto mb-1" />
            <p className="text-slate-300">Real-time</p>
          </div>
          <div className="text-center p-2 bg-slate-700/20 rounded">
            <Eye className="w-4 h-4 text-blue-400 mx-auto mb-1" />
            <p className="text-slate-300">95% Accuracy</p>
          </div>
          <div className="text-center p-2 bg-slate-700/20 rounded">
            <CheckCircle className="w-4 h-4 text-green-400 mx-auto mb-1" />
            <p className="text-slate-300">Offline Ready</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}