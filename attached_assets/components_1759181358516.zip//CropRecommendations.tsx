import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Skeleton } from './ui/skeleton';
import { 
  Brain, 
  TrendingUp, 
  Droplets, 
  DollarSign,
  Leaf,
  Star,
  Zap,
  BarChart3,
  Sprout,
  Target
} from 'lucide-react';

interface CropRecommendation {
  id: string;
  crop: string;
  matchScore: number;
  expectedYield: string;
  profitMargin: string;
  waterRequirement: string;
  sustainability: string;
  marketDemand: string;
}

interface CropRecommendationsProps {
  recommendations?: CropRecommendation[];
  isLoading?: boolean;
}

export function CropRecommendations({ recommendations, isLoading }: CropRecommendationsProps) {
  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <Skeleton className="h-6 w-64" />
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="p-4 border border-slate-700 rounded-lg">
              <Skeleton className="h-6 w-32 mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-20 w-full" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  const defaultRecommendations: CropRecommendation[] = [
    {
      id: '1',
      crop: 'Pearl Millet',
      matchScore: 95,
      expectedYield: '2.5-3 tons/ha',
      profitMargin: '₹45,000/ha',
      waterRequirement: 'Low (350mm)',
      sustainability: 'Excellent',
      marketDemand: 'High'
    },
    {
      id: '2',
      crop: 'Groundnut',
      matchScore: 88,
      expectedYield: '1.5-2 tons/ha',
      profitMargin: '₹35,000/ha',
      waterRequirement: 'Medium (500mm)',
      sustainability: 'Good',
      marketDemand: 'High'
    }
  ];

  const crops = recommendations || defaultRecommendations;

  const getCropIcon = (crop: string) => {
    if (crop.toLowerCase().includes('millet')) return '🌾';
    if (crop.toLowerCase().includes('groundnut')) return '🥜';
    return '🌱';
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-400';
    if (score >= 80) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Brain className="w-5 h-5 text-purple-400" />
            </div>
            AI Crop Recommendations
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Zap className="w-4 h-4 mr-2" />
              Run Analysis
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Recommendations */}
        <div className="grid gap-4">
          {crops.map((crop, index) => (
            <motion.div
              key={crop.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative overflow-hidden"
            >
              <div className="p-4 bg-gradient-to-r from-slate-700/50 to-slate-600/30 rounded-lg border border-slate-600">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{getCropIcon(crop.crop)}</div>
                    <div>
                      <h3 className="font-semibold text-white text-lg">{crop.crop}</h3>
                      <p className="text-sm text-slate-400">Field recommendation</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${getScoreColor(crop.matchScore)}`}>
                      {crop.matchScore}%
                    </div>
                    <p className="text-xs text-slate-400">Match Score</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center p-3 bg-slate-600/30 rounded-lg">
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      <span className="text-xs text-slate-300">Expected Yield</span>
                    </div>
                    <p className="font-semibold text-green-400">{crop.expectedYield}</p>
                  </div>

                  <div className="text-center p-3 bg-slate-600/30 rounded-lg">
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <DollarSign className="w-4 h-4 text-blue-400" />
                      <span className="text-xs text-slate-300">Profit Margin</span>
                    </div>
                    <p className="font-semibold text-blue-400">{crop.profitMargin}</p>
                  </div>

                  <div className="text-center p-3 bg-slate-600/30 rounded-lg">
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <Droplets className="w-4 h-4 text-cyan-400" />
                      <span className="text-xs text-slate-300">Water Need</span>
                    </div>
                    <p className="font-semibold text-cyan-400">{crop.waterRequirement}</p>
                  </div>

                  <div className="text-center p-3 bg-slate-600/30 rounded-lg">
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <Leaf className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs text-slate-300">Sustainability</span>
                    </div>
                    <div className="flex items-center justify-center gap-1">
                      <span className="font-semibold text-emerald-400">{crop.sustainability}</span>
                      {crop.sustainability === 'Excellent' && (
                        <div className="flex">
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">Market Demand:</span>
                    <Badge className={crop.marketDemand === 'High' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}>
                      {crop.marketDemand}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">Crop Resistance Variety:</span>
                    <span className="text-blue-400">Drought resistant variety</span>
                  </div>

                  <Progress 
                    value={crop.matchScore} 
                    className="mt-3"
                  />
                </div>

                {/* Match Score Indicator */}
                <div className="absolute top-2 right-2">
                  <Badge className={crop.matchScore >= 90 ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}>
                    <Target className="w-3 h-3 mr-1" />
                    {crop.matchScore}% Match
                  </Badge>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Market Analysis Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="p-4 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-lg border border-blue-500/30"
        >
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-5 h-5 text-blue-400" />
            <h3 className="font-semibold text-white">Detailed Market & Risk Analysis</h3>
          </div>
          
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-400">₹2,150</div>
              <p className="text-xs text-slate-300">Current Market Price/quintal</p>
              <p className="text-xs text-green-400">+12% from last month</p>
            </div>
            
            <div>
              <div className="text-2xl font-bold text-blue-400">85%</div>
              <p className="text-xs text-slate-300">Weather Favorability</p>
              <p className="text-xs text-blue-400">Good monsoon predicted</p>
            </div>
            
            <div>
              <div className="text-2xl font-bold text-purple-400">Low</div>
              <p className="text-xs text-slate-300">Risk Assessment</p>
              <p className="text-xs text-purple-400">Stable market variety</p>
            </div>
          </div>
        </motion.div>
      </CardContent>
    </Card>
  );
}