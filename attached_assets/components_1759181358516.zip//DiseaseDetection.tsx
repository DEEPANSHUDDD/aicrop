import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Camera, 
  Upload, 
  Scan, 
  AlertTriangle,
  CheckCircle,
  Leaf,
  Microscope,
  Brain
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { apiService } from '../utils/api';

interface DetectionResult {
  disease: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high';
  treatment: string;
  prevention: string;
  affectedArea: string;
}

export function DiseaseDetection() {
  const [isScanning, setIsScanning] = useState(false);
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const processDetection = async (imageData: string) => {
    setIsScanning(true);
    
    try {
      // Call backend API for disease detection
      const result = await apiService.detectDisease(imageData, 'default');
      
      setDetectionResult({
        disease: result.disease || 'Healthy Crop',
        confidence: result.confidence,
        severity: result.severity || 'low',
        treatment: result.treatment || 'No treatment needed - crop appears healthy.',
        prevention: result.prevention,
        affectedArea: result.affectedArea
      });
    } catch (error) {
      console.error('Disease detection error:', error);
      setDetectionResult({
        disease: 'Detection Error',
        confidence: 0,
        severity: 'high',
        treatment: 'Unable to analyze image. Please try again with a clearer photo.',
        prevention: 'Ensure good lighting and focus when taking photos.',
        affectedArea: 'Unknown'
      });
    } finally {
      setIsScanning(false);
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target?.result as string;
        setUploadedImage(imageData);
        processDetection(imageData);
      };
      reader.readAsDataURL(file);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <Card className="col-span-full lg:col-span-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Microscope className="w-5 h-5" />
          AI Disease Detection
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Upload Section */}
        <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
          {uploadedImage ? (
            <div className="space-y-4">
              <img 
                src={uploadedImage} 
                alt="Uploaded crop" 
                className="w-full max-w-xs mx-auto rounded-lg object-cover"
              />
              <Button onClick={() => {
                setUploadedImage(null);
                setDetectionResult(null);
              }} variant="outline" size="sm">
                Upload New Image
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="p-4 bg-muted rounded-full">
                  <Camera className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
              <div>
                <h3 className="font-medium">Upload Crop Image</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Take a clear photo of affected leaves or crops for AI analysis
                </p>
              </div>
              <div className="flex gap-2 justify-center">
                <Button asChild>
                  <label htmlFor="image-upload" className="cursor-pointer">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Image
                  </label>
                </Button>
                <input
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <Button variant="outline" onClick={() => {
                  // Mock camera capture with stock image
                  const mockImageUrl = 'https://images.unsplash.com/photo-1754106005357-2095d15fb965?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBmYXJtJTIwY3JvcHN8ZW58MXx8fHwxNzU4ODg2MTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral';
                  setUploadedImage(mockImageUrl);
                  processDetection(mockImageUrl);
                }}>
                  <Camera className="w-4 h-4 mr-2" />
                  Camera
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Scanning State */}
        {isScanning && (
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-4 bg-primary/10 rounded-full animate-pulse">
                <Scan className="w-8 h-8 text-primary animate-spin" />
              </div>
            </div>
            <div>
              <h3 className="font-medium">AI Analysis in Progress</h3>
              <p className="text-sm text-muted-foreground">
                Analyzing image using computer vision and deep learning models...
              </p>
              <Progress value={85} className="w-full max-w-xs mx-auto mt-2" />
            </div>
          </div>
        )}

        {/* Detection Results */}
        {detectionResult && !isScanning && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              <h3 className="font-medium">Detection Results</h3>
            </div>

            <div className="border border-border rounded-lg p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-6 h-6 text-orange-500" />
                  <div>
                    <h4 className="font-medium text-lg">{detectionResult.disease}</h4>
                    <p className="text-sm text-muted-foreground">
                      Affected area: {detectionResult.affectedArea}
                    </p>
                  </div>
                </div>
                <Badge className={getSeverityColor(detectionResult.severity)}>
                  {detectionResult.severity.toUpperCase()} RISK
                </Badge>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Detection Confidence</span>
                  <span className="text-sm font-bold">{detectionResult.confidence}%</span>
                </div>
                <Progress value={detectionResult.confidence} className="w-full" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h5 className="font-medium flex items-center gap-1">
                    <Leaf className="w-4 h-4" />
                    Treatment
                  </h5>
                  <p className="text-sm text-muted-foreground">
                    {detectionResult.treatment}
                  </p>
                </div>
                <div className="space-y-2">
                  <h5 className="font-medium flex items-center gap-1">
                    <CheckCircle className="w-4 h-4" />
                    Prevention
                  </h5>
                  <p className="text-sm text-muted-foreground">
                    {detectionResult.prevention}
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button size="sm">
                  Order Treatment
                </Button>
                <Button size="sm" variant="outline">
                  Consult Expert
                </Button>
                <Button size="sm" variant="ghost">
                  Save Report
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Recent Scans */}
        <div>
          <h4 className="font-medium mb-3">Recent Scans</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1754106005357-2095d15fb965?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBmYXJtJTIwY3JvcHN8ZW58MXx8fHwxNzU4ODg2MTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Previous scan"
                className="w-12 h-12 rounded object-cover"
              />
              <div className="flex-1">
                <p className="font-medium text-sm">Field A - Tomatoes</p>
                <p className="text-xs text-muted-foreground">2 hours ago</p>
                <Badge variant="secondary" className="text-xs mt-1">Healthy</Badge>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
              <ImageWithFallback  
                src="https://images.unsplash.com/photo-1754106005357-2095d15fb965?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBmYXJtJTIwY3JvcHN8ZW58MXx8fHwxNzU4ODg2MTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Previous scan"
                className="w-12 h-12 rounded object-cover"
              />
              <div className="flex-1">
                <p className="font-medium text-sm">Field B - Wheat</p>
                <p className="text-xs text-muted-foreground">1 day ago</p>
                <Badge className="text-xs mt-1 bg-orange-100 text-orange-800">Rust Detected</Badge>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}