import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  Wind, 
  Droplets, 
  Thermometer,
  Eye,
  Gauge
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
  pressure: number;
  forecast: Array<{
    day: string;
    high: number;
    low: number;
    condition: string;
    icon: string;
  }>;
  alerts: Array<{
    type: string;
    message: string;
    severity: 'low' | 'medium' | 'high';
  }>;
}

const weatherIcons = {
  sunny: Sun,
  cloudy: Cloud,
  rainy: CloudRain,
  windy: Wind,
};

interface WeatherCardProps {
  data: WeatherData;
}

export function WeatherCard({ data }: WeatherCardProps) {
  const CurrentIcon = weatherIcons[data.condition.toLowerCase() as keyof typeof weatherIcons] || Sun;

  return (
    <Card className="col-span-full lg:col-span-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CurrentIcon className="w-5 h-5" />
          Weather & Climate
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Weather */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-2xl font-bold">{data.temperature}°C</h3>
              <CurrentIcon className="w-8 h-8 text-primary" />
            </div>
            <p className="text-muted-foreground">{data.location}</p>
            <p className="text-sm capitalize">{data.condition}</p>
          </div>
          <div className="text-right">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1571733949554-f9c9c0bbdab3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWF0aGVyJTIwc3RhdGlvbiUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU4ODg2MTAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Weather station"
              className="w-16 h-16 rounded-lg object-cover"
            />
          </div>
        </div>

        {/* Weather Details */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-blue-500" />
            <div>
              <p className="text-sm text-muted-foreground">Humidity</p>
              <p className="font-medium">{data.humidity}%</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Wind className="w-4 h-4 text-green-500" />
            <div>
              <p className="text-sm text-muted-foreground">Wind</p>
              <p className="font-medium">{data.windSpeed} km/h</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-purple-500" />
            <div>
              <p className="text-sm text-muted-foreground">Visibility</p>
              <p className="font-medium">{data.visibility} km</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-orange-500" />
            <div>
              <p className="text-sm text-muted-foreground">Pressure</p>
              <p className="font-medium">{data.pressure} hPa</p>
            </div>
          </div>
        </div>

        {/* 5-Day Forecast */}
        <div>
          <h4 className="font-medium mb-3">5-Day Forecast</h4>
          <div className="grid grid-cols-5 gap-2">
            {data.forecast.map((day, index) => {
              const DayIcon = weatherIcons[day.condition.toLowerCase() as keyof typeof weatherIcons] || Sun;
              return (
                <div key={index} className="text-center p-2 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground font-medium">{day.day}</p>
                  <DayIcon className="w-5 h-5 mx-auto my-2 text-primary" />
                  <p className="text-sm font-medium">{day.high}°</p>
                  <p className="text-xs text-muted-foreground">{day.low}°</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weather Alerts */}
        {data.alerts.length > 0 && (
          <div>
            <h4 className="font-medium mb-3">Weather Alerts</h4>
            <div className="space-y-2">
              {data.alerts.map((alert, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Badge 
                    variant={alert.severity === 'high' ? 'destructive' : alert.severity === 'medium' ? 'default' : 'secondary'}
                  >
                    {alert.type}
                  </Badge>
                  <p className="text-sm">{alert.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}