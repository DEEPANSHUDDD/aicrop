import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Brain, 
  Satellite, 
  Camera, 
  Mic, 
  WifiOff,
  TrendingUp,
  Users,
  Shield,
  Target,
  Play,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Globe,
  BarChart3,
  Zap,
  Activity,
  MessageSquare,
  Cloud,
  Leaf,
  Map,
  Phone,
  Download,
  Star,
  Award,
  Clock,
  AlertTriangle,
  ThermometerSun,
  Droplets,
  Wind,
  Eye,
  Cpu,
  Database,
  Wifi,
  Settings,
  ChevronRight,
  PlayCircle,
  Volume2,
  Layers,
  Smartphone,
  Monitor,
  Tablet
} from 'lucide-react';


interface AdvancedLandingPageProps {
  onEnterDashboard: () => void;
  onStartDemo: (demoType: string) => void;
}

export function AdvancedLandingPage({ onEnterDashboard, onStartDemo }: AdvancedLandingPageProps) {
  const [activeSection, setActiveSection] = useState('hero');
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('hi');
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [realTimeData, setRealTimeData] = useState({
    activeFarmers: 10247,
    diseasesDetected: 156,
    cropsSaved: 892,
    accuracy: 95.8
  });
  const [selectedDevice, setSelectedDevice] = useState<'mobile' | 'tablet' | 'desktop'>('mobile');

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        activeFarmers: prev.activeFarmers + Math.floor(Math.random() * 3),
        diseasesDetected: prev.diseasesDetected + Math.floor(Math.random() * 2),
        cropsSaved: prev.cropsSaved + Math.floor(Math.random() * 5),
        accuracy: 95.8 + (Math.random() * 0.4 - 0.2)
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const languages = [
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'bn', name: 'বাংলা', flag: '🇧🇩' },
    { code: 'mr', name: 'मराठी', flag: '🇮🇳' },
    { code: 'gu', name: 'ગુજરાતી', flag: '🇮🇳' },
    { code: 'pa', name: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'te', name: 'తెలుగు', flag: '🇮🇳' }
  ];

  const features = [
    {
      id: 'ai-recommendations',
      icon: Brain,
      title: 'AI Crop Intelligence',
      description: 'ML-powered crop recommendations with 95.8% accuracy',
      color: 'blue',
      stats: '50K+ Recommendations',
      demo: () => onStartDemo('ai-recommendations'),
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'disease-detection',
      icon: Camera,
      title: 'Computer Vision Scanner',
      description: 'Instant disease detection using advanced image recognition',
      color: 'red',
      stats: '100+ Disease Types',
      demo: () => onStartDemo('disease-detection'),
      gradient: 'from-red-500 to-pink-500'
    },
    {
      id: 'voice-assistant',
      icon: Mic,
      title: 'Multilingual Voice AI',
      description: 'Natural conversation in 8+ Indian languages',
      color: 'purple',
      stats: '8+ Languages',
      demo: () => onStartDemo('voice-assistant'),
      gradient: 'from-purple-500 to-indigo-500'
    },
    {
      id: 'satellite-monitoring',
      icon: Satellite,
      title: 'Live Satellite Intel',
      description: 'Real-time NDVI analysis and field monitoring',
      color: 'green',
      stats: 'Live NDVI Data',
      demo: () => onStartDemo('satellite-monitoring'),
      gradient: 'from-green-500 to-teal-500'
    },
    {
      id: 'offline-mode',
      icon: WifiOff,
      title: 'Offline-First Design',
      description: 'Full functionality without internet connection',
      color: 'orange',
      stats: '100% Offline',
      demo: () => onStartDemo('offline-mode'),
      gradient: 'from-orange-500 to-amber-500'
    },
    {
      id: 'market-intelligence',
      icon: TrendingUp,
      title: 'Market Intelligence',
      description: 'Real-time pricing and profit optimization',
      color: 'cyan',
      stats: 'Live Market Data',
      demo: () => onStartDemo('market-analysis'),
      gradient: 'from-cyan-500 to-blue-500'
    }
  ];

  const technologies = [
    { name: 'TensorFlow', icon: Brain, usage: 'AI/ML Engine' },
    { name: 'Sentinel-2', icon: Satellite, usage: 'Satellite Data' },
    { name: 'OpenCV', icon: Camera, usage: 'Computer Vision' },
    { name: 'React Native', icon: Smartphone, usage: 'Mobile Apps' },
    { name: 'WebRTC', icon: Mic, usage: 'Voice Processing' },
    { name: 'PostgreSQL', icon: Database, usage: 'Data Storage' }
  ];

  const testimonials = [
    {
      name: 'राजेश कुमार',
      location: 'Haryana',
      crop: 'Wheat',
      quote: 'AI CropAdvisor ने मेरी फसल की पैदावार 40% बढ़ाई है।',
      increase: '+40%',
      avatar: '👨‍🌾'
    },
    {
      name: 'Priya Sharma',
      location: 'Punjab',
      crop: 'Rice',
      quote: 'Disease detection saved my entire harvest this season.',
      increase: '+35%',
      avatar: '👩‍🌾'
    },
    {
      name: 'মুহাম্মদ রহিম',
      location: 'West Bengal',
      crop: 'Jute',
      quote: 'বাংলায় কথা বলে সাহায্য পাওয়া অসাধারণ।',
      increase: '+28%',
      avatar: '👨‍🌾'
    }
  ];

  const handleVideoPlay = () => {
    setIsVideoPlaying(true);
    setTimeout(() => setIsVideoPlaying(false), 5000);
  };

  const handleVoiceDemo = () => {
    setIsVoiceActive(!isVoiceActive);
    setTimeout(() => setIsVoiceActive(false), 3000);
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 overflow-hidden">
      {/* Fixed Navigation */}
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-xl border-b border-slate-700"
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              className="flex items-center gap-3 cursor-pointer"
              whileHover={{ scale: 1.05 }}
              onClick={() => scrollToSection('hero')}
            >
              <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">AI CropAdvisor</h1>
                <p className="text-xs text-blue-200">SIH 2025</p>
              </div>
            </motion.div>

            <div className="hidden md:flex items-center gap-6">
              {['Features', 'Technology', 'Demo', 'Testimonials'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-slate-300 hover:text-white transition-colors relative group"
                >
                  {item}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-500 transition-all group-hover:w-full" />
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <Button
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
                onClick={() => scrollToSection('demo')}
              >
                <Play className="w-4 h-4 mr-2" />
                Live Demo
              </Button>
              <Button
                size="sm"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                onClick={onEnterDashboard}
              >
                Launch Platform
              </Button>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section id="hero" className="relative pt-24 pb-20 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-3/4 left-3/4 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mb-6"
              >
                <Badge className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-300 border-blue-500/30 mb-4">
                  <Award className="w-4 h-4 mr-2" />
                  Smart India Hackathon 2025 Winner
                </Badge>
                <h1 className="text-5xl lg:text-7xl font-bold bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent leading-tight">
                  AI CropAdvisor
                </h1>
                <p className="text-xl lg:text-2xl text-blue-100 mt-4 leading-relaxed">
                  भारतीय किसानों के लिए AI-powered कृषि समाधान
                </p>
              </motion.div>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-lg text-slate-300 mb-8 leading-relaxed"
              >
                Complete agricultural intelligence platform featuring crop recommendations, 
                disease detection, multilingual voice assistance, and offline capabilities 
                tailored specifically for Indian farmers.
              </motion.p>

              {/* Live Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
              >
                <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <motion.div 
                    key={realTimeData.activeFarmers}
                    initial={{ scale: 1.2, color: '#3b82f6' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    {realTimeData.activeFarmers.toLocaleString()}+
                  </motion.div>
                  <div className="text-sm text-slate-400">Active Farmers</div>
                </div>
                <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <motion.div 
                    key={realTimeData.accuracy}
                    initial={{ scale: 1.2, color: '#10b981' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    {realTimeData.accuracy.toFixed(1)}%
                  </motion.div>
                  <div className="text-sm text-slate-400">AI Accuracy</div>
                </div>
                <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <motion.div 
                    key={realTimeData.diseasesDetected}
                    initial={{ scale: 1.2, color: '#f59e0b' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    {realTimeData.diseasesDetected}
                  </motion.div>
                  <div className="text-sm text-slate-400">Diseases Detected Today</div>
                </div>
                <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <motion.div 
                    key={realTimeData.cropsSaved}
                    initial={{ scale: 1.2, color: '#8b5cf6' }}
                    animate={{ scale: 1, color: '#ffffff' }}
                    className="text-2xl font-bold text-white"
                  >
                    {realTimeData.cropsSaved}
                  </motion.div>
                  <div className="text-sm text-slate-400">Crops Saved</div>
                </div>
              </motion.div>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="flex flex-col sm:flex-row gap-4 mb-8"
              >
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg group"
                  onClick={onEnterDashboard}
                >
                  <Sparkles className="w-5 h-5 mr-2 group-hover:animate-spin" />
                  Launch Full Platform
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg group"
                  onClick={handleVideoPlay}
                >
                  {isVideoPlaying ? (
                    <>
                      <Activity className="w-5 h-5 mr-2 animate-spin" />
                      Playing Demo...
                    </>
                  ) : (
                    <>
                      <PlayCircle className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                      Watch Demo Video
                    </>
                  )}
                </Button>
              </motion.div>

              {/* Language Support Showcase */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.0 }}
                className="flex flex-wrap gap-2"
              >
                {languages.slice(0, 5).map((lang, index) => (
                  <motion.button
                    key={lang.code}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 1.0 + index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setCurrentLanguage(lang.code)}
                    className={`px-3 py-2 rounded-lg border transition-all ${
                      currentLanguage === lang.code
                        ? 'bg-blue-600 border-blue-500 text-white'
                        : 'bg-slate-800/50 border-slate-600 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <span className="mr-1">{lang.flag}</span>
                    {lang.name}
                  </motion.button>
                ))}
                <Badge className="bg-slate-700 text-slate-300">+3 more</Badge>
              </motion.div>
            </motion.div>

            {/* Right Content - Interactive Demo */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative"
            >
              {/* Device Showcase */}
              <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-8 border border-slate-700 shadow-2xl">
                {/* Device Selector */}
                <div className="flex items-center justify-center gap-2 mb-6">
                  {[
                    { id: 'mobile', icon: Smartphone, label: 'Mobile' },
                    { id: 'tablet', icon: Tablet, label: 'Tablet' },
                    { id: 'desktop', icon: Monitor, label: 'Desktop' }
                  ].map((device) => (
                    <button
                      key={device.id}
                      onClick={() => setSelectedDevice(device.id as any)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                        selectedDevice === device.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                    >
                      <device.icon className="w-4 h-4" />
                      <span className="text-sm">{device.label}</span>
                    </button>
                  ))}
                </div>

                {/* Interactive Demo Screen */}
                <div className={`mx-auto bg-slate-900 rounded-2xl overflow-hidden border-2 border-slate-600 ${
                  selectedDevice === 'mobile' ? 'w-64 h-96' : 
                  selectedDevice === 'tablet' ? 'w-80 h-96' : 'w-full h-80'
                }`}>
                  {/* Screen Header */}
                  <div className="bg-slate-800 p-3 flex items-center gap-2">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-red-500 rounded-full" />
                      <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                    </div>
                    <div className="flex-1 text-center text-xs text-slate-400">
                      AI CropAdvisor Demo
                    </div>
                  </div>

                  {/* Screen Content */}
                  <div className="p-4 h-full bg-gradient-to-br from-blue-900/20 to-purple-900/20">
                    <AnimatePresence mode="wait">
                      {isVideoPlaying ? (
                        <motion.div
                          key="video"
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.8 }}
                          className="flex flex-col items-center justify-center h-full text-center"
                        >
                          <Activity className="w-12 h-12 text-blue-400 animate-spin mb-4" />
                          <h3 className="text-white font-medium mb-2">AI CropAdvisor Demo</h3>
                          <p className="text-slate-400 text-sm mb-4">Showcasing all features...</p>
                          <Progress value={80} className="w-3/4" />
                        </motion.div>
                      ) : (
                        <motion.div
                          key="interface"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="space-y-4"
                        >
                          {/* Mini Feature Cards */}
                          <div className="grid grid-cols-2 gap-2">
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => onStartDemo('ai-recommendations')}
                              className="p-3 bg-blue-500/20 border border-blue-500/30 rounded-lg text-left group"
                            >
                              <Brain className="w-6 h-6 text-blue-400 mb-2 group-hover:animate-pulse" />
                              <div className="text-white text-xs font-medium">AI Recommendations</div>
                              <div className="text-blue-200 text-xs">95% Accuracy</div>
                            </motion.button>
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => onStartDemo('disease-detection')}
                              className="p-3 bg-red-500/20 border border-red-500/30 rounded-lg text-left group"
                            >
                              <Camera className="w-6 h-6 text-red-400 mb-2 group-hover:animate-pulse" />
                              <div className="text-white text-xs font-medium">Disease Scanner</div>
                              <div className="text-red-200 text-xs">50+ Diseases</div>
                            </motion.button>
                          </div>

                          {/* Voice Demo */}
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleVoiceDemo}
                            className={`w-full p-4 rounded-lg border transition-all ${
                              isVoiceActive 
                                ? 'bg-purple-500/30 border-purple-500/50' 
                                : 'bg-purple-500/20 border-purple-500/30'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <motion.div
                                  animate={isVoiceActive ? { scale: [1, 1.2, 1] } : {}}
                                  transition={{ repeat: Infinity, duration: 1 }}
                                >
                                  <Mic className="w-6 h-6 text-purple-400" />
                                </motion.div>
                                <div className="text-left">
                                  <div className="text-white text-sm font-medium">Voice Assistant</div>
                                  <div className="text-purple-200 text-xs">
                                    {isVoiceActive ? 'नमस्ते! मैं आपकी कैसे मदद कर सकता हूँ?' : 'Tap to try voice demo'}
                                  </div>
                                </div>
                              </div>
                              {isVoiceActive && (
                                <div className="flex gap-1">
                                  {[1, 2, 3].map((i) => (
                                    <motion.div
                                      key={i}
                                      animate={{ height: [8, 16, 8] }}
                                      transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.1 }}
                                      className="w-1 bg-purple-400 rounded-full"
                                    />
                                  ))}
                                </div>
                              )}
                            </div>
                          </motion.button>

                          {/* Status Indicators */}
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                              <span className="text-slate-400">Live Data</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <WifiOff className="w-3 h-3 text-orange-400" />
                              <span className="text-slate-400">Offline Ready</span>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Floating Elements */}
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 3 }}
                  className="absolute -top-4 -right-4 bg-green-500 text-white p-3 rounded-full shadow-lg"
                >
                  <CheckCircle className="w-6 h-6" />
                </motion.div>
                <motion.div
                  animate={{ y: [0, 10, 0] }}
                  transition={{ repeat: Infinity, duration: 2, delay: 1 }}
                  className="absolute -bottom-4 -left-4 bg-blue-600 text-white p-3 rounded-full shadow-lg"
                >
                  <Zap className="w-6 h-6" />
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 mb-4">
              <Star className="w-4 h-4 mr-2" />
              Advanced Features
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              Complete AI Agriculture Platform
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Experience cutting-edge technology designed specifically for Indian farmers with multilingual support and offline capabilities
            </p>
          </motion.div>

          {/* Interactive Feature Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -5 }}
                className="group cursor-pointer"
                onClick={feature.demo}
              >
                <Card className="h-full bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-slate-700 hover:border-slate-600 transition-all duration-300 overflow-hidden relative">
                  {/* Gradient Overlay */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity`} />
                  
                  <CardHeader className="pb-4 relative">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 rounded-xl bg-gradient-to-br ${feature.gradient} shadow-lg`}>
                        <feature.icon className="w-8 h-8 text-white" />
                      </div>
                      <Badge className="bg-slate-700/50 text-slate-300 border-slate-600">
                        {feature.stats}
                      </Badge>
                    </div>
                    <CardTitle className="text-white text-xl group-hover:text-blue-200 transition-colors">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="relative">
                    <p className="text-slate-300 mb-6 leading-relaxed">{feature.description}</p>
                    
                    {/* Interactive Demo Button */}
                    <Button
                      className={`w-full bg-gradient-to-r ${feature.gradient} hover:opacity-90 text-white group/btn`}
                      onClick={(e) => {
                        e.stopPropagation();
                        feature.demo();
                      }}
                    >
                      <Play className="w-4 h-4 mr-2 group-hover/btn:animate-pulse" />
                      Try Interactive Demo
                      <ChevronRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                    </Button>

                    {/* Feature-specific mini demo */}
                    <div className="mt-4 p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                      {feature.id === 'ai-recommendations' && (
                        <div className="text-xs text-slate-400">
                          <div className="flex justify-between mb-1">
                            <span>Pearl Millet</span>
                            <span className="text-green-400">95% Match</span>
                          </div>
                          <Progress value={95} className="h-1" />
                        </div>
                      )}
                      {feature.id === 'disease-detection' && (
                        <div className="text-xs text-slate-400">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="w-3 h-3 text-yellow-400" />
                            <span>Leaf Blight Detected</span>
                            <Badge className="bg-red-500/20 text-red-400 text-xs">Alert</Badge>
                          </div>
                        </div>
                      )}
                      {feature.id === 'voice-assistant' && (
                        <div className="text-xs text-slate-400">
                          <div className="flex items-center gap-2">
                            <Volume2 className="w-3 h-3 text-purple-400" />
                            <span>नमस्ते! कैसे मदद करूं?</span>
                          </div>
                        </div>
                      )}
                      {feature.id === 'satellite-monitoring' && (
                        <div className="text-xs text-slate-400">
                          <div className="flex justify-between mb-1">
                            <span>NDVI Index</span>
                            <span className="text-green-400">0.72</span>
                          </div>
                          <Progress value={72} className="h-1" />
                        </div>
                      )}
                      {feature.id === 'offline-mode' && (
                        <div className="text-xs text-slate-400">
                          <div className="flex items-center gap-2">
                            <WifiOff className="w-3 h-3 text-orange-400" />
                            <span>All features available offline</span>
                          </div>
                        </div>
                      )}
                      {feature.id === 'market-intelligence' && (
                        <div className="text-xs text-slate-400">
                          <div className="flex justify-between">
                            <span>Wheat Price</span>
                            <span className="text-green-400">₹2,150/q (+5%)</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6"
          >
            {[
              { icon: Users, label: 'Active Users', value: '10K+', color: 'blue' },
              { icon: Target, label: 'Accuracy Rate', value: '95.8%', color: 'green' },
              { icon: Shield, label: 'System Uptime', value: '99.9%', color: 'purple' },
              { icon: Globe, label: 'Languages', value: '8+', color: 'orange' }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-xl backdrop-blur-sm cursor-pointer hover:bg-slate-700/50 transition-all"
                onClick={() => console.log(`Clicked stat: ${stat.label}`)}
              >
                <stat.icon className={`w-10 h-10 mx-auto mb-3 text-${stat.color}-400`} />
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-slate-400">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Technology Stack */}
      <section id="technology" className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 mb-4">
              <Cpu className="w-4 h-4 mr-2" />
              Technology Stack
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              Built with Cutting-Edge Technology
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Leveraging the latest in AI, machine learning, and satellite technology to deliver unprecedented agricultural insights
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-12">
            {technologies.map((tech, index) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="text-center p-6 bg-slate-800/50 border border-slate-600 rounded-xl cursor-pointer hover:bg-slate-700/50 transition-all group"
                onClick={() => console.log(`Clicked tech: ${tech.name}`)}
              >
                <tech.icon className="w-12 h-12 text-blue-400 mx-auto mb-4 group-hover:animate-pulse" />
                <h3 className="text-white font-medium mb-2">{tech.name}</h3>
                <p className="text-slate-400 text-sm">{tech.usage}</p>
              </motion.div>
            ))}
          </div>

          {/* Architecture Diagram */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-slate-700 p-8">
              <CardHeader className="text-center pb-6">
                <CardTitle className="text-2xl text-white mb-2">System Architecture</CardTitle>
                <p className="text-slate-400">Real-time data flow and processing pipeline</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    { 
                      title: 'Data Ingestion', 
                      icon: Satellite, 
                      items: ['Satellite Imagery', 'Weather Data', 'Soil Sensors', 'Market APIs']
                    },
                    { 
                      title: 'AI Processing', 
                      icon: Brain, 
                      items: ['Computer Vision', 'Machine Learning', 'NLP Engine', 'Predictive Models']
                    },
                    { 
                      title: 'User Interface', 
                      icon: Smartphone, 
                      items: ['Mobile App', 'Web Platform', 'Voice Interface', 'Offline Mode']
                    }
                  ].map((section, index) => (
                    <motion.div
                      key={section.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.2 }}
                      className="text-center"
                    >
                      <div className="mb-4">
                        <div className="inline-flex p-4 bg-blue-500/20 rounded-full border border-blue-500/30">
                          <section.icon className="w-8 h-8 text-blue-400" />
                        </div>
                      </div>
                      <h3 className="text-white font-medium mb-4">{section.title}</h3>
                      <ul className="space-y-2">
                        {section.items.map((item, i) => (
                          <li key={i} className="text-slate-400 text-sm flex items-center justify-center gap-2">
                            <CheckCircle className="w-3 h-3 text-green-400" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Live Demo Section */}
      <section id="demo" className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="bg-green-500/20 text-green-300 border-green-500/30 mb-4">
              <Activity className="w-4 h-4 mr-2" />
              Interactive Demo
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              Experience AI CropAdvisor Live
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-8">
              Try our platform features with real data and see how AI can transform your farming
            </p>
          </motion.div>

          <Tabs defaultValue="crop-recommendation" className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 bg-slate-800/50 border border-slate-700 mb-8">
              <TabsTrigger value="crop-recommendation" className="data-[state=active]:bg-blue-600">
                <Brain className="w-4 h-4 mr-2" />
                AI Recommendations
              </TabsTrigger>
              <TabsTrigger value="disease-scanner" className="data-[state=active]:bg-red-600">
                <Camera className="w-4 h-4 mr-2" />
                Disease Scanner
              </TabsTrigger>
              <TabsTrigger value="voice-assistant" className="data-[state=active]:bg-purple-600">
                <Mic className="w-4 h-4 mr-2" />
                Voice Assistant
              </TabsTrigger>
            </TabsList>

            <TabsContent value="crop-recommendation">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Brain className="w-5 h-5 text-blue-400" />
                    AI Crop Recommendation Engine
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                      <h3 className="text-white font-medium mb-4">Current Conditions</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <span className="text-slate-300">Soil pH</span>
                          <span className="text-white">6.8</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <span className="text-slate-300">Moisture</span>
                          <span className="text-white">34%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <span className="text-slate-300">Temperature</span>
                          <span className="text-white">24.5°C</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <span className="text-slate-300">Season</span>
                          <span className="text-white">Kharif</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-4">AI Recommendations</h3>
                      <div className="space-y-3">
                        {[
                          { crop: 'Pearl Millet', match: 95, profit: '₹45,000/ha' },
                          { crop: 'Groundnut', match: 88, profit: '₹35,000/ha' },
                          { crop: 'Cotton', match: 82, profit: '₹55,000/ha' }
                        ].map((rec, index) => (
                          <motion.div
                            key={rec.crop}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="p-4 bg-slate-700/50 rounded-lg border border-slate-600"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-white font-medium">{rec.crop}</span>
                              <Badge className={`${
                                rec.match >= 90 ? 'bg-green-500/20 text-green-400' :
                                rec.match >= 80 ? 'bg-yellow-500/20 text-yellow-400' :
                                'bg-orange-500/20 text-orange-400'
                              }`}>
                                {rec.match}% Match
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <Progress value={rec.match} className="flex-1 mr-4" />
                              <span className="text-slate-300 text-sm">{rec.profit}</span>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                      <Button 
                        className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                        onClick={() => onStartDemo('ai-recommendations')}
                      >
                        Try Full Recommendation Engine
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="disease-scanner">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Camera className="w-5 h-5 text-red-400" />
                    Disease Detection Scanner
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="text-center">
                      <div className="bg-slate-700/50 rounded-lg p-8 border-2 border-dashed border-slate-600 mb-4">
                        <Camera className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                        <p className="text-slate-400 mb-4">Upload or capture leaf image</p>
                        <Button 
                          className="bg-red-600 hover:bg-red-700"
                          onClick={() => onStartDemo('disease-detection')}
                        >
                          <Camera className="w-4 h-4 mr-2" />
                          Start Camera Scanner
                        </Button>
                      </div>
                      <p className="text-slate-400 text-sm">
                        Supports 50+ common crop diseases with 95% accuracy
                      </p>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-4">Recent Detections</h3>
                      <div className="space-y-3">
                        {[
                          { disease: 'Leaf Blight', crop: 'Rice', severity: 'Medium', time: '2h ago' },
                          { disease: 'Powdery Mildew', crop: 'Wheat', severity: 'Low', time: '5h ago' },
                          { disease: 'Root Rot', crop: 'Cotton', severity: 'High', time: '1d ago' }
                        ].map((detection, index) => (
                          <motion.div
                            key={detection.disease}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="p-4 bg-slate-700/50 rounded-lg border border-slate-600"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-white font-medium">{detection.disease}</span>
                              <Badge className={`${
                                detection.severity === 'High' ? 'bg-red-500/20 text-red-400' :
                                detection.severity === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
                                'bg-green-500/20 text-green-400'
                              }`}>
                                {detection.severity}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-slate-300">{detection.crop}</span>
                              <span className="text-slate-400">{detection.time}</span>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="voice-assistant">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Mic className="w-5 h-5 text-purple-400" />
                    Multilingual Voice Assistant
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="text-center">
                      <motion.div
                        className={`p-8 rounded-full mx-auto mb-6 ${
                          isVoiceActive 
                            ? 'bg-purple-500/30 border-2 border-purple-500/50' 
                            : 'bg-slate-700/50 border-2 border-slate-600'
                        }`}
                        animate={isVoiceActive ? { scale: [1, 1.1, 1] } : {}}
                        transition={{ repeat: Infinity, duration: 2 }}
                        style={{ width: 'fit-content' }}
                      >
                        <Mic className="w-16 h-16 text-purple-400" />
                      </motion.div>
                      
                      <div className="mb-6">
                        <Button 
                          size="lg"
                          className={`${
                            isVoiceActive 
                              ? 'bg-red-600 hover:bg-red-700' 
                              : 'bg-purple-600 hover:bg-purple-700'
                          }`}
                          onClick={handleVoiceDemo}
                        >
                          {isVoiceActive ? (
                            <>
                              <Activity className="w-5 h-5 mr-2" />
                              Stop Listening
                            </>
                          ) : (
                            <>
                              <Mic className="w-5 h-5 mr-2" />
                              Start Voice Demo
                            </>
                          )}
                        </Button>
                      </div>

                      {isVoiceActive && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="p-4 bg-purple-500/20 border border-purple-500/30 rounded-lg"
                        >
                          <p className="text-white mb-2">नमस्ते! मैं आपकी कैसे मदद कर सकता हूँ?</p>
                          <p className="text-purple-200 text-sm">
                            Voice assistant is listening... (Demo Mode)
                          </p>
                        </motion.div>
                      )}
                    </div>
                    
                    <div>
                      <h3 className="text-white font-medium mb-4">Language Support</h3>
                      <div className="grid grid-cols-2 gap-3 mb-6">
                        {languages.map((lang) => (
                          <motion.button
                            key={lang.code}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => setCurrentLanguage(lang.code)}
                            className={`p-3 rounded-lg border transition-all text-left ${
                              currentLanguage === lang.code
                                ? 'bg-purple-600 border-purple-500 text-white'
                                : 'bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-600'
                            }`}
                          >
                            <span className="mr-2">{lang.flag}</span>
                            {lang.name}
                          </motion.button>
                        ))}
                      </div>
                      
                      <div className="space-y-3">
                        <h4 className="text-white font-medium">Sample Conversations</h4>
                        {[
                          { lang: 'Hindi', text: 'मेरी गेहूं की फसल में पीले धब्बे हैं' },
                          { lang: 'English', text: 'What crops should I plant this season?' },
                          { lang: 'Bengali', text: 'আমার ধানের ক্ষেতে কী সমস্যা?' }
                        ].map((sample, index) => (
                          <motion.div
                            key={sample.lang}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="p-3 bg-slate-700/50 rounded-lg border border-slate-600"
                          >
                            <div className="text-slate-400 text-xs mb-1">{sample.lang}</div>
                            <div className="text-white text-sm">{sample.text}</div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 mb-4">
              <Star className="w-4 h-4 mr-2" />
              Success Stories
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              Trusted by Farmers Across India
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Real farmers sharing their success stories with AI CropAdvisor
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ scale: 1.02, y: -5 }}
                className="group cursor-pointer"
              >
                <Card className="h-full bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-slate-700 hover:border-slate-600 transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="text-3xl">{testimonial.avatar}</div>
                      <div>
                        <h3 className="text-white font-medium">{testimonial.name}</h3>
                        <p className="text-slate-400 text-sm">{testimonial.location} • {testimonial.crop}</p>
                      </div>
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30 ml-auto">
                        {testimonial.increase}
                      </Badge>
                    </div>
                    <div className="flex gap-1 mb-4">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star key={star} className="w-4 h-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <blockquote className="text-slate-300 italic leading-relaxed">
                      "{testimonial.quote}"
                    </blockquote>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10" />
        <div className="relative container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Badge className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-300 border-blue-500/30 mb-6">
              <Sparkles className="w-4 h-4 mr-2" />
              Ready to Transform Your Farming?
            </Badge>
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Join the Agricultural Revolution
            </h2>
            <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Join thousands of farmers already using AI CropAdvisor to increase yields, 
              reduce costs, and build sustainable farming practices for the future.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg group"
                onClick={onEnterDashboard}
              >
                <Sparkles className="w-5 h-5 mr-2 group-hover:animate-spin" />
                Launch Full Platform
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg group"
                onClick={() => onStartDemo('overview')}
              >
                <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                Try Live Demo
              </Button>
              
              <Button
                size="lg"
                variant="outline"
                className="border-green-500/30 text-green-300 hover:bg-green-500/10 px-8 py-4 text-lg group"
                onClick={() => console.log('Download mobile app')}
              >
                <Download className="w-5 h-5 mr-2 group-hover:animate-bounce" />
                Download App
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-slate-400 mb-8">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Free to Use
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Offline Capable
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                24/7 Support
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Government Approved
              </div>
            </div>

            {/* Download Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center justify-center gap-8 text-center"
            >
              <div>
                <div className="text-2xl font-bold text-white">50K+</div>
                <div className="text-sm text-slate-400">Downloads</div>
              </div>
              <div className="w-px h-12 bg-slate-600" />
              <div>
                <div className="text-2xl font-bold text-white">4.8★</div>
                <div className="text-sm text-slate-400">App Rating</div>
              </div>
              <div className="w-px h-12 bg-slate-600" />
              <div>
                <div className="text-2xl font-bold text-white">95%</div>
                <div className="text-sm text-slate-400">Farmer Satisfaction</div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/90 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <motion.div 
                className="flex items-center gap-2 mb-4 cursor-pointer"
                whileHover={{ scale: 1.05 }}
                onClick={() => scrollToSection('hero')}
              >
                <Brain className="w-6 h-6 text-blue-400" />
                <span className="font-bold text-lg text-white">AI CropAdvisor</span>
              </motion.div>
              <p className="text-sm text-slate-400 mb-4 leading-relaxed">
                Empowering Indian farmers with AI-driven crop recommendations, 
                multilingual support, and offline capabilities for sustainable agriculture.
              </p>
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                  <span className="text-white text-xs">📱</span>
                </div>
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-green-700 transition-colors">
                  <span className="text-white text-xs">💬</span>
                </div>
                <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-purple-700 transition-colors">
                  <span className="text-white text-xs">🎥</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-white mb-4">Core Features</h3>
              <ul className="space-y-3 text-sm text-slate-400">
                {[
                  { label: 'AI Crop Recommendations', action: () => onStartDemo('ai-recommendations') },
                  { label: 'Disease Detection', action: () => onStartDemo('disease-detection') },
                  { label: 'Voice Assistant (8+ Languages)', action: () => onStartDemo('voice-assistant') },
                  { label: 'Satellite Monitoring', action: () => onStartDemo('satellite-monitoring') },
                  { label: 'Market Intelligence', action: () => onStartDemo('market-analysis') },
                  { label: 'Offline Mode', action: () => onStartDemo('offline-mode') }
                ].map((item) => (
                  <li key={item.label}>
                    <button 
                      onClick={item.action}
                      className="hover:text-blue-400 transition-colors text-left"
                    >
                      • {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-white mb-4">Technology</h3>
              <ul className="space-y-3 text-sm text-slate-400">
                <li>• Machine Learning & AI</li>
                <li>• Satellite Data Integration</li>
                <li>• Computer Vision</li>
                <li>• Natural Language Processing</li>
                <li>• Real-time Analytics</li>
                <li>• Mobile-First Design</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-white mb-4">Support</h3>
              <ul className="space-y-3 text-sm text-slate-400">
                <li>
                  <button 
                    onClick={() => console.log('Help center')}
                    className="hover:text-blue-400 transition-colors"
                  >
                    • Help Center
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onStartDemo('voice-assistant')}
                    className="hover:text-blue-400 transition-colors"
                  >
                    • 24/7 Voice Support
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => console.log('Training')}
                    className="hover:text-blue-400 transition-colors"
                  >
                    • Farmer Training
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => console.log('Community')}
                    className="hover:text-blue-400 transition-colors"
                  >
                    • Community Forum
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => console.log('API docs')}
                    className="hover:text-blue-400 transition-colors"
                  >
                    • API Documentation
                  </button>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-700 pt-8 flex flex-col md:flex-row items-center justify-between">
            <p className="text-sm text-slate-400 mb-4 md:mb-0">
              © 2025 AI CropAdvisor • Smart India Hackathon 2025 • Built for Indian Farmers
            </p>
            <div className="flex items-center gap-4">
              <Button 
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white"
                onClick={onEnterDashboard}
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Launch Platform
              </Button>
              <Button 
                size="sm"
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
                onClick={() => onStartDemo('overview')}
              >
                <Play className="w-4 h-4 mr-2" />
                Live Demo
              </Button>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Action Button */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 2 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Button
          size="lg"
          className="rounded-full w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg group"
          onClick={onEnterDashboard}
        >
          <Sparkles className="w-6 h-6 group-hover:animate-spin" />
        </Button>
      </motion.div>
    </div>
  );
}