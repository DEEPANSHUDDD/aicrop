import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { NotificationCenter } from './NotificationCenter';
import { 
  Mic, 
  MicOff, 
  Bell, 
  Settings, 
  User,
  Brain,
  Globe,
  MessageSquare,
  ChevronDown,
  Search,
  Home,
  HelpCircle,
  LogOut,
  Menu
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface HeaderProps {
  onVoiceToggle: (active: boolean) => void;
  onChatToggle?: (active: boolean) => void;
  isVoiceActive: boolean;
  isChatOpen?: boolean;
  onNavigate?: (section: string) => void;
}

export function Header({ onVoiceToggle, onChatToggle, isVoiceActive, isChatOpen, onNavigate }: HeaderProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [unreadNotifications, setUnreadNotifications] = useState(3);
  const [selectedLanguage, setSelectedLanguage] = useState('hi');

  const languages = [
    { code: 'hi', name: 'हिंदी', english: 'Hindi' },
    { code: 'en', name: 'English', english: 'English' },
    { code: 'bn', name: 'বাংলা', english: 'Bengali' },
    { code: 'mr', name: 'मराठी', english: 'Marathi' },
    { code: 'gu', name: 'ગુજરાતી', english: 'Gujarati' }
  ];

  const currentLanguage = languages.find(lang => lang.code === selectedLanguage);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // Implement search functionality
    console.log('Searching for:', query);
  };

  const handleNotificationClick = (notification: any) => {
    console.log('Notification clicked:', notification);
    setShowNotifications(false);
    // Navigate to relevant section based on notification
    if (onNavigate) {
      switch (notification.category) {
        case 'weather':
          onNavigate('analysis');
          break;
        case 'disease':
          onNavigate('overview');
          break;
        case 'market':
          onNavigate('analysis');
          break;
        default:
          onNavigate('overview');
      }
    }
  };

  const handleLanguageChange = (langCode: string) => {
    setSelectedLanguage(langCode);
    console.log('Language changed to:', langCode);
    // Implement language switching logic
  };

  const handleVoiceToggle = () => {
    const newState = !isVoiceActive;
    onVoiceToggle(newState);
    console.log('Voice assistant:', newState ? 'activated' : 'deactivated');
  };

  const handleChatToggle = () => {
    if (onChatToggle) {
      const newState = !isChatOpen;
      onChatToggle(newState);
      console.log('Chat:', newState ? 'opened' : 'closed');
    }
  };

  const handleSettingsClick = () => {
    console.log('Opening settings');
    if (onNavigate) {
      onNavigate('settings');
    }
  };

  const handleProfileClick = () => {
    console.log('Opening profile');
    if (onNavigate) {
      onNavigate('profile');
    }
  };

  const handleHomeClick = () => {
    console.log('Navigating to home');
    if (onNavigate) {
      onNavigate('overview');
    }
  };

  return (
    <>
      <header className="border-b border-slate-700 bg-slate-900/90 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo and Title */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-3 cursor-pointer"
              onClick={handleHomeClick}
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                    <Brain className="w-7 h-7 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-slate-900" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white hover:text-blue-200 transition-colors">
                    AI CropAdvisor
                  </h1>
                  <p className="text-sm text-blue-200">SIH 2025 Innovation</p>
                </div>
              </div>
            </motion.div>

            {/* Search Bar - Hidden on mobile */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="hidden md:flex items-center flex-1 max-w-md mx-8"
            >
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search crops, diseases, recommendations..."
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400 focus:border-blue-500"
                />
              </div>
            </motion.div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              {/* Mobile Menu */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="md:hidden"
              >
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <Menu className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-slate-800 border-slate-600">
                    <DropdownMenuItem onClick={handleHomeClick}>
                      <Home className="w-4 h-4 mr-2" />
                      Home
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleSettingsClick}>
                      <Settings className="w-4 h-4 mr-2" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => console.log('Help clicked')}>
                      <HelpCircle className="w-4 h-4 mr-2" />
                      Help
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </motion.div>

              {/* Language Selector */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="hidden sm:block"
              >
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <Globe className="w-4 h-4 mr-2" />
                      <span className="hidden md:inline">{currentLanguage?.name}</span>
                      <span className="md:hidden">{currentLanguage?.code.toUpperCase()}</span>
                      <ChevronDown className="w-3 h-3 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-slate-800 border-slate-600">
                    <DropdownMenuLabel className="text-slate-300">Select Language</DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-slate-600" />
                    {languages.map((lang) => (
                      <DropdownMenuItem
                        key={lang.code}
                        onClick={() => handleLanguageChange(lang.code)}
                        className={`text-slate-300 hover:bg-slate-700 ${
                          selectedLanguage === lang.code ? 'bg-blue-600/20' : ''
                        }`}
                      >
                        <span className="mr-2">{lang.name}</span>
                        <span className="text-slate-500 text-sm">({lang.english})</span>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </motion.div>

              {/* Voice Control */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Button
                  variant={isVoiceActive ? "default" : "outline"}
                  size="sm"
                  onClick={handleVoiceToggle}
                  className={isVoiceActive 
                    ? "bg-purple-600 hover:bg-purple-700 text-white" 
                    : "border-slate-600 text-slate-300 hover:bg-slate-700"
                  }
                >
                  {isVoiceActive ? (
                    <Mic className="w-4 h-4 sm:mr-2" />
                  ) : (
                    <MicOff className="w-4 h-4 sm:mr-2" />
                  )}
                  <span className="hidden sm:inline">Voice</span>
                </Button>
              </motion.div>

              {/* Chat Toggle */}
              {onChatToggle && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <Button
                    variant={isChatOpen ? "default" : "outline"}
                    size="sm"
                    onClick={handleChatToggle}
                    className={isChatOpen 
                      ? "bg-blue-600 hover:bg-blue-700 text-white" 
                      : "border-slate-600 text-slate-300 hover:bg-slate-700"
                    }
                  >
                    <MessageSquare className="w-4 h-4 sm:mr-2" />
                    <span className="hidden sm:inline">Chat</span>
                  </Button>
                </motion.div>
              )}

              {/* Notifications */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="relative border-slate-600 text-slate-300 hover:bg-slate-700"
                  onClick={() => setShowNotifications(!showNotifications)}
                >
                  <Bell className="w-4 h-4" />
                  {unreadNotifications > 0 && (
                    <Badge 
                      className="absolute -top-2 -right-2 w-5 h-5 text-xs flex items-center justify-center p-0 bg-red-500 text-white border-0 animate-pulse"
                    >
                      {unreadNotifications > 9 ? '9+' : unreadNotifications}
                    </Badge>
                  )}
                </Button>
              </motion.div>

              {/* Settings */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="hidden sm:block"
              >
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-slate-600 text-slate-300 hover:bg-slate-700"
                  onClick={handleSettingsClick}
                >
                  <Settings className="w-4 h-4" />
                </Button>
              </motion.div>

              {/* User Profile */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
              >
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <User className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-slate-800 border-slate-600" align="end">
                    <DropdownMenuLabel className="text-slate-300">
                      <div>
                        <p className="font-medium">Farmer User</p>
                        <p className="text-sm text-slate-500">farmer@example.com</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-slate-600" />
                    <DropdownMenuItem 
                      onClick={handleProfileClick}
                      className="text-slate-300 hover:bg-slate-700"
                    >
                      <User className="w-4 h-4 mr-2" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={handleSettingsClick}
                      className="text-slate-300 hover:bg-slate-700"
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => console.log('Help clicked')}
                      className="text-slate-300 hover:bg-slate-700"
                    >
                      <HelpCircle className="w-4 h-4 mr-2" />
                      Help & Support
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-slate-600" />
                    <DropdownMenuItem 
                      onClick={() => console.log('Logout clicked')}
                      className="text-red-400 hover:bg-red-500/10"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </motion.div>
            </div>
          </div>
        </div>
      </header>

      {/* Notification Center */}
      {showNotifications && (
        <NotificationCenter
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)}
          onNotificationClick={handleNotificationClick}
        />
      )}
    </>
  );
}