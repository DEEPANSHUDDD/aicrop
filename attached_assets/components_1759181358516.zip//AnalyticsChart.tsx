import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  TrendingUp, 
  BarChart3, 
  PieChart as PieChartIcon,
  Download,
  Calendar,
  Activity,
  Target
} from 'lucide-react';

interface AnalyticsData {
  yieldData: Array<{
    month: string;
    wheat: number;
    rice: number;
    corn: number;
  }>;
  revenueData: Array<{
    month: string;
    revenue: number;
    expenses: number;
    profit: number;
  }>;
  cropDistribution: Array<{
    name: string;
    value: number;
    color: string;
  }>;
  weatherImpact: Array<{
    date: string;
    temperature: number;
    rainfall: number;
    yield: number;
  }>;
}

interface AnalyticsChartProps {
  data?: AnalyticsData;
  expanded?: boolean;
}

// Default data for demo
const defaultData: AnalyticsData = {
  yieldData: [
    { month: 'Jan', wheat: 2.5, rice: 3.2, corn: 4.1 },
    { month: 'Feb', wheat: 2.8, rice: 3.5, corn: 4.3 },
    { month: 'Mar', wheat: 3.1, rice: 3.8, corn: 4.6 },
    { month: 'Apr', wheat: 3.4, rice: 4.1, corn: 4.9 },
    { month: 'May', wheat: 3.6, rice: 4.3, corn: 5.1 },
    { month: 'Jun', wheat: 3.9, rice: 4.6, corn: 5.4 }
  ],
  revenueData: [
    { month: 'Jan', revenue: 45000, expenses: 25000, profit: 20000 },
    { month: 'Feb', revenue: 52000, expenses: 28000, profit: 24000 },
    { month: 'Mar', revenue: 48000, expenses: 26000, profit: 22000 },
    { month: 'Apr', revenue: 61000, expenses: 32000, profit: 29000 },
    { month: 'May', revenue: 55000, expenses: 30000, profit: 25000 },
    { month: 'Jun', revenue: 67000, expenses: 35000, profit: 32000 }
  ],
  cropDistribution: [
    { name: 'Wheat', value: 35, color: '#8884d8' },
    { name: 'Rice', value: 30, color: '#82ca9d' },
    { name: 'Corn', value: 25, color: '#ffc658' },
    { name: 'Others', value: 10, color: '#ff7300' }
  ],
  weatherImpact: [
    { date: '01/24', temperature: 25, rainfall: 45, yield: 85 },
    { date: '02/24', temperature: 28, rainfall: 35, yield: 78 },
    { date: '03/24', temperature: 32, rainfall: 55, yield: 92 },
    { date: '04/24', temperature: 30, rainfall: 48, yield: 88 },
    { date: '05/24', temperature: 35, rainfall: 25, yield: 72 },
    { date: '06/24', temperature: 29, rainfall: 62, yield: 95 }
  ]
};

export function AnalyticsChart({ data, expanded = false }: AnalyticsChartProps) {
  const analyticsData = data || defaultData;
  const { yieldData, revenueData, cropDistribution, weatherImpact } = analyticsData;
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={expanded ? "col-span-full" : ""}
    >
      <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-white">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <BarChart3 className="w-5 h-5 text-green-400" />
              </div>
              Farm Analytics & Insights
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <Activity className="w-3 h-3 mr-1" />
                Live Data
              </Badge>
              <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                <Calendar className="w-4 h-4 mr-2" />
                Last 6 Months
              </Button>
              <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
      <CardContent>
        <Tabs defaultValue="yield" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="yield">Crop Yield</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="distribution">Crop Mix</TabsTrigger>
            <TabsTrigger value="weather">Weather Impact</TabsTrigger>
          </TabsList>

          <TabsContent value="yield" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Crop Yield Trends (Tons/Hectare)</h3>
              <div className="flex gap-2">
                <Badge className="bg-blue-100 text-blue-800">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +12% YoY
                </Badge>
              </div>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={yieldData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="wheat" 
                    stroke="#8884d8" 
                    strokeWidth={2}
                    name="Wheat"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="rice" 
                    stroke="#82ca9d" 
                    strokeWidth={2}
                    name="Rice"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="corn" 
                    stroke="#ffc658" 
                    strokeWidth={2}
                    name="Corn"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="revenue" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Revenue & Profit Analysis (₹)</h3>
              <div className="flex gap-2">
                <Badge className="bg-green-100 text-green-800">
                  Profit Margin: 50.4%
                </Badge>
              </div>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`₹${value.toLocaleString()}`, '']} />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stackId="1" 
                    stroke="#8884d8" 
                    fill="#8884d8"
                    name="Revenue"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="profit" 
                    stackId="2" 
                    stroke="#82ca9d" 
                    fill="#82ca9d"
                    name="Profit"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="distribution" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Land Distribution by Crop Type</h3>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={cropDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {cropDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-4">
                <h4 className="font-medium">Crop Details</h4>
                {cropDistribution.map((crop, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded-full" 
                        style={{ backgroundColor: crop.color }}
                      />
                      <span className="font-medium">{crop.name}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{crop.value}%</p>
                      <p className="text-sm text-muted-foreground">
                        {(crop.value * 2.5).toFixed(1)} hectares
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="weather" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Weather Impact on Yield</h3>
              <Badge variant="secondary">
                Correlation: Temperature vs Rainfall vs Yield
              </Badge>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weatherImpact}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="temperature" 
                    fill="#ff7300" 
                    name="Temperature (°C)"
                  />
                  <Bar 
                    yAxisId="left" 
                    dataKey="rainfall" 
                    fill="#0088fe" 
                    name="Rainfall (mm)"
                  />
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="yield" 
                    stroke="#00ff00" 
                    strokeWidth={3}
                    name="Yield Index"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>

        {/* Key Insights */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 p-4 bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg"
        >
          <div className="flex items-center gap-2 mb-3">
            <Target className="w-5 h-5 text-green-400" />
            <h4 className="font-medium text-white">AI-Generated Insights</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="text-green-300">
              <p className="font-medium">• Yield Optimization</p>
              <p className="text-slate-400">Corn showing highest growth potential with 15% increase this quarter</p>
            </div>
            <div className="text-blue-300">
              <p className="font-medium">• Weather Correlation</p>
              <p className="text-slate-400">Optimal rainfall (45-65mm) correlates with 20% higher yields</p>
            </div>
            <div className="text-purple-300">
              <p className="font-medium">• Revenue Growth</p>
              <p className="text-slate-400">Consistent 8% month-over-month revenue growth maintained</p>
            </div>
          </div>
        </motion.div>
      </CardContent>
    </Card>
    </motion.div>
  );
}