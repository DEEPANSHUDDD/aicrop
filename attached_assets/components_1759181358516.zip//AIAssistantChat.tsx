import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  MessageSquare, 
  Mic, 
  Send, 
  X, 
  Volume2,
  Bot,
  User,
  Sparkles,
  Leaf,
  TrendingUp
} from 'lucide-react';

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

interface AIAssistantChatProps {
  isOpen: boolean;
  onClose?: () => void;
  isFloating?: boolean;
}

export function AIAssistantChat({ isOpen, onClose, isFloating = false }: AIAssistantChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'user',
      content: 'My soil has low moisture and the weather is hot. Which crop should I plant?',
      timestamp: new Date(Date.now() - 300000)
    },
    {
      id: '2',
      type: 'ai',
      content: 'Based on your soil and weather conditions, I recommend the following crops:',
      timestamp: new Date(Date.now() - 250000),
      suggestions: ['Pearl Millet', 'Groundnut']
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: newMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: getAIResponse(newMessage),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 2000);
  };

  const getAIResponse = (input: string): string => {
    const responses = [
      "Based on current satellite data and weather patterns, I recommend focusing on drought-resistant crops for optimal yield.",
      "Your soil analysis shows optimal conditions for nitrogen-fixing crops. Consider legumes for sustainable farming.",
      "Current market prices favor pearl millet. Expected profit margin is ₹45,000/ha with 95% success rate.",
      "Weather forecast indicates rainfall in 3 days. Perfect timing for sowing operations."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleVoiceToggle = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Start voice recording
      setTimeout(() => {
        setIsRecording(false);
        setNewMessage("Voice message: Check soil moisture levels");
      }, 3000);
    }
  };

  const containerClasses = isFloating 
    ? "w-96 h-[500px]" 
    : "w-full max-w-4xl mx-auto h-[600px]";

  return (
    <Card className={`${containerClasses} bg-slate-800/90 border-slate-700 backdrop-blur-sm flex flex-col`}>
      <CardHeader className="flex flex-row items-center justify-between pb-4 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="bg-gradient-to-br from-blue-500 to-purple-600">
              <AvatarFallback className="bg-transparent text-white">
                <Bot className="w-5 h-5" />
              </AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-slate-800" />
          </div>
          <div>
            <CardTitle className="text-white text-lg">AI CropAdvisor</CardTitle>
            <p className="text-sm text-slate-400">Multilingual Agricultural Assistant</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
            <Sparkles className="w-3 h-3 mr-1" />
            Voice
          </Badge>
          <Badge variant="secondary" className="bg-blue-500/20 text-blue-400 border-blue-500/30">
            हिंदी
          </Badge>
          {isFloating && onClose && (
            <Button size="sm" variant="ghost" onClick={onClose} className="text-slate-400">
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-4 overflow-hidden flex flex-col">
        {/* Demo Badge */}
        <div className="flex items-center justify-center mb-4">
          <Badge className="bg-blue-600/20 text-blue-400 border-blue-500/30">
            <MessageSquare className="w-3 h-3 mr-1" />
            AI Assistant Chat Demo
          </Badge>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 mb-4">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.type === 'ai' && (
                  <Avatar className="bg-gradient-to-br from-blue-500 to-purple-600 w-8 h-8">
                    <AvatarFallback className="bg-transparent text-white text-xs">
                      <Bot className="w-4 h-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div className={`max-w-[80%] ${message.type === 'user' ? 'order-last' : ''}`}>
                  <div
                    className={`p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-blue-600 text-white ml-auto'
                        : 'bg-slate-700 text-white'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    {message.type === 'user' && (
                      <p className="text-xs text-blue-200 mt-1">Farmer • Voice input</p>
                    )}
                  </div>
                  
                  {message.suggestions && (
                    <div className="mt-2 space-y-2">
                      {message.suggestions.map((suggestion, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="bg-slate-600/50 rounded-lg p-3 border border-slate-600"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Leaf className="w-4 h-4 text-green-400" />
                              <span className="font-medium text-white">{suggestion}</span>
                            </div>
                            <Badge className={index === 0 ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"}>
                              {index === 0 ? "95% Match" : "88% Match"}
                            </Badge>
                          </div>
                          <div className="text-xs text-slate-300 space-y-1">
                            <div className="flex justify-between">
                              <span>Expected Yield:</span>
                              <span className="text-green-400">{index === 0 ? "2.5-3 tons/ha" : "1.5-2 tons/ha"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Profit Margin:</span>
                              <span className="text-blue-400">{index === 0 ? "₹45,000/ha" : "₹35,000/ha"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Water Requirement:</span>
                              <span className="text-orange-400">{index === 0 ? "Low (350mm)" : "Medium (500mm)"}</span>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                      
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
                        <Sparkles className="w-3 h-3" />
                        Satellite data analyzed • Real-time processing
                      </div>
                    </div>
                  )}
                </div>

                {message.type === 'user' && (
                  <Avatar className="bg-green-600 w-8 h-8">
                    <AvatarFallback className="bg-transparent text-white text-xs">
                      <User className="w-4 h-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-3"
            >
              <Avatar className="bg-gradient-to-br from-blue-500 to-purple-600 w-8 h-8">
                <AvatarFallback className="bg-transparent text-white text-xs">
                  <Bot className="w-4 h-4" />
                </AvatarFallback>
              </Avatar>
              <div className="bg-slate-700 rounded-lg p-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100" />
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-200" />
                </div>
              </div>
            </motion.div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="flex items-center gap-2 p-3 bg-slate-700/50 rounded-lg border border-slate-600">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your question or press the mic button..."
            className="flex-1 bg-transparent border-none text-white placeholder-slate-400"
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          />
          <Button
            size="sm"
            variant={isRecording ? "default" : "ghost"}
            onClick={handleVoiceToggle}
            className={`${isRecording ? 'bg-red-600 text-white' : 'text-slate-400'}`}
          >
            <Mic className={`w-4 h-4 ${isRecording ? 'animate-pulse' : ''}`} />
          </Button>
          <Button
            size="sm"
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {/* Demo Button */}
        <div className="mt-3 text-center">
          <Button 
            variant="outline" 
            size="sm" 
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Full SIM Demo
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}