import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  MessageSquare,
  Brain,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { apiService } from '../utils/api';

interface VoiceMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  audioUrl?: string;
}

interface VoiceInterfaceProps {
  isActive: boolean;
  onToggle: (active: boolean) => void;
}

export function VoiceInterface({ isActive, onToggle }: VoiceInterfaceProps) {
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<VoiceMessage[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Hello! I\'m your AI farming assistant. You can ask me about weather, crop recommendations, market prices, or any farming-related questions. Try saying "What\'s the weather forecast?" or "Show me crop recommendations".',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
    }
  ]);

  // Voice recognition simulation with API integration
  const simulateVoiceInput = async () => {
    setIsListening(true);
    
    // Simulate listening for 3 seconds
    setTimeout(async () => {
      setIsListening(false);
      setIsProcessing(true);
      
      // Add user message
      const userQueries = [
        "What's the weather forecast for next week?",
        "Should I water my tomato plants today?",
        "What are the current wheat prices?",
        "When should I harvest my corn crop?",
        "Is there any disease detected in my fields?",
        "Show me irrigation recommendations"
      ];
      
      const randomQuery = userQueries[Math.floor(Math.random() * userQueries.length)];
      
      const userMessage: VoiceMessage = {
        id: Date.now().toString(),
        type: 'user',
        content: randomQuery,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      
      try {
        // Call backend API for AI processing
        const response = await apiService.processVoiceCommand(randomQuery, 'default');
        
        const aiMessage: VoiceMessage = {
          id: (Date.now() + 1).toString(),
          type: 'ai',
          content: response.response,
          timestamp: new Date(response.timestamp),
        };
        
        setMessages(prev => [...prev, aiMessage]);
      } catch (error) {
        console.error('Voice command error:', error);
        const errorMessage: VoiceMessage = {
          id: (Date.now() + 1).toString(),
          type: 'ai',
          content: 'Sorry, I encountered an error processing your request. Please try again.',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, errorMessage]);
      } finally {
        setIsProcessing(false);
      }
    }, 3000);
  };

  const playAudio = (message: VoiceMessage) => {
    // Mock text-to-speech
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(message.content);
      utterance.rate = 0.8;
      utterance.pitch = 1;
      speechSynthesis.speak(utterance);
    }
  };

  if (!isActive) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-4 right-4 w-96 max-w-[calc(100vw-2rem)] z-50"
    >
      <Card className="shadow-lg border-2">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              <span>AI Voice Assistant</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggle(false)}
              className="h-6 w-6 p-0"
            >
              ×
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Messages */}
          <div className="h-64 overflow-y-auto space-y-3">
            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs opacity-70">
                        {message.timestamp.toLocaleTimeString([], { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </span>
                      {message.type === 'ai' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => playAudio(message)}
                          className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
                        >
                          <Volume2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            {isProcessing && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="bg-muted text-muted-foreground p-3 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">AI is thinking...</span>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Voice Controls */}
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              {isListening && (
                <Badge variant="default" className="animate-pulse">
                  <Mic className="w-3 h-3 mr-1" />
                  Listening...
                </Badge>
              )}
              {isProcessing && (
                <Badge variant="secondary">
                  <Brain className="w-3 h-3 mr-1" />
                  Processing...
                </Badge>
              )}
            </div>
            
            <Button
              onClick={simulateVoiceInput}
              disabled={isListening || isProcessing}
              className={`${isListening ? 'animate-pulse bg-red-500 hover:bg-red-600' : ''}`}
            >
              {isListening ? (
                <MicOff className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => simulateVoiceInput()}
              disabled={isListening || isProcessing}
            >
              Weather
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => simulateVoiceInput()}
              disabled={isListening || isProcessing}
            >
              Irrigation
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => simulateVoiceInput()}
              disabled={isListening || isProcessing}
            >
              Prices
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}