import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Globe, 
  Volume2, 
  Mic,
  CheckCircle,
  Play,
  Languages
} from 'lucide-react';

interface Language {
  code: string;
  name: string;
  native: string;
  flag: string;
  speakers: string;
  region: string;
  status: 'fully-supported' | 'beta' | 'coming-soon';
  sampleText: string;
  voiceDemo?: string;
}

export function LanguageSupport() {
  const [selectedLanguage, setSelectedLanguage] = useState<string>('hi');
  const [isPlaying, setIsPlaying] = useState<string | null>(null);

  const languages: Language[] = [
    {
      code: 'hi',
      name: 'Hindi',
      native: 'हिंदी',
      flag: '🇮🇳',
      speakers: '600M+',
      region: 'North India',
      status: 'fully-supported',
      sampleText: 'आपकी फसल के लिए मक्का एक अच्छा विकल्प है।',
      voiceDemo: 'Your crop recommendation is ready in Hindi'
    },
    {
      code: 'bn',
      name: 'Bengali',
      native: 'বাংলা',
      flag: '🇮🇳',
      speakers: '300M+',
      region: 'Bengal',
      status: 'fully-supported',
      sampleText: 'আপনার মাটির জন্য ধান চাষ উপযুক্ত হবে।',
      voiceDemo: 'Your crop recommendation is ready in Bengali'
    },
    {
      code: 'mr',
      name: 'Marathi',
      native: 'मराठी',
      flag: '🇮🇳',
      speakers: '95M+',
      region: 'Maharashtra',
      status: 'fully-supported',
      sampleText: 'तुमच्या शेतासाठी ज्वारी चांगली पिके आहे।',
      voiceDemo: 'Your crop recommendation is ready in Marathi'
    },
    {
      code: 'gu',
      name: 'Gujarati',
      native: 'ગુજરાતી',
      flag: '🇮🇳',
      speakers: '60M+',
      region: 'Gujarat',
      status: 'fully-supported',
      sampleText: 'તમારા ખેત માટે મગફળી સારો વિકલ્પ છે।',
      voiceDemo: 'Your crop recommendation is ready in Gujarati'
    },
    {
      code: 'ta',
      name: 'Tamil',
      native: 'தமிழ்',
      flag: '🇮🇳',
      speakers: '80M+',
      region: 'Tamil Nadu',
      status: 'fully-supported',
      sampleText: 'உங்கள் நிலத்திற்கு நெல் சாகுபடி சிறந்தது.',
      voiceDemo: 'Your crop recommendation is ready in Tamil'
    },
    {
      code: 'te',
      name: 'Telugu',
      native: 'తెలుగు',
      flag: '🇮🇳',
      speakers: '95M+',
      region: 'Andhra Pradesh',
      status: 'fully-supported',
      sampleText: 'మీ భూమికి వరి సాగు అనుకూలంగా ఉంటుంది.',
      voiceDemo: 'Your crop recommendation is ready in Telugu'
    },
    {
      code: 'kn',
      name: 'Kannada',
      native: 'ಕನ್ನಡ',
      flag: '🇮🇳',
      speakers: '50M+',
      region: 'Karnataka',
      status: 'beta',
      sampleText: 'ನಿಮ್ಮ ಭೂಮಿಗೆ ರಾಗಿ ಬೆಳೆ ಸೂಕ್ತವಾಗಿರುತ್ತದೆ.',
      voiceDemo: 'Your crop recommendation is ready in Kannada'
    },
    {
      code: 'pa',
      name: 'Punjabi',
      native: 'ਪੰਜਾਬੀ',
      flag: '🇮🇳',
      speakers: '35M+',
      region: 'Punjab',
      status: 'beta',
      sampleText: 'ਤੁਹਾਡੀ ਖੇਤੀ ਲਈ ਕਣਕ ਇੱਕ ਚੰਗਾ ਵਿਕਲਪ ਹੈ।',
      voiceDemo: 'Your crop recommendation is ready in Punjabi'
    }
  ];

  const handleVoiceDemo = (langCode: string) => {
    setIsPlaying(langCode);
    // Simulate voice playback
    setTimeout(() => {
      setIsPlaying(null);
    }, 3000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'fully-supported': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'beta': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'coming-soon': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  const selectedLang = languages.find(lang => lang.code === selectedLanguage);

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold text-white mb-4">Multilingual Voice Support</h2>
        <p className="text-lg text-slate-300 mb-6">
          Comprehensive language support for farmers across India
        </p>
        <div className="flex items-center justify-center gap-6 text-sm text-slate-400">
          <div className="flex items-center gap-2">
            <Languages className="w-4 h-4 text-blue-400" />
            8+ Indian Languages
          </div>
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-green-400" />
            Text-to-Speech
          </div>
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-purple-400" />
            Speech Recognition
          </div>
        </div>
      </motion.div>

      {/* Language Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
        {languages.map((lang, index) => (
          <motion.div
            key={lang.code}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card 
              className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                selectedLanguage === lang.code 
                  ? 'bg-blue-600/20 border-blue-500' 
                  : 'bg-slate-800/50 border-slate-600'
              }`}
              onClick={() => setSelectedLanguage(lang.code)}
            >
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2">{lang.flag}</div>
                <div className="text-lg font-medium text-white mb-1">{lang.native}</div>
                <div className="text-xs text-slate-400 mb-2">{lang.name}</div>
                <Badge className={getStatusColor(lang.status)}>
                  {lang.status === 'fully-supported' ? '✓' : lang.status === 'beta' ? 'β' : '⏳'}
                </Badge>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Selected Language Details */}
      {selectedLang && (
        <motion.div
          key={selectedLanguage}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-6"
        >
          {/* Language Info */}
          <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <span className="text-3xl">{selectedLang.flag}</span>
                <div>
                  <div className="text-2xl">{selectedLang.native}</div>
                  <div className="text-lg text-slate-400">{selectedLang.name}</div>
                </div>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-slate-400">Speakers:</span>
                  <div className="text-white font-medium">{selectedLang.speakers}</div>
                </div>
                <div>
                  <span className="text-slate-400">Region:</span>
                  <div className="text-white font-medium">{selectedLang.region}</div>
                </div>
              </div>
              
              <div>
                <span className="text-slate-400 text-sm">Status:</span>
                <div className="mt-1">
                  <Badge className={getStatusColor(selectedLang.status)}>
                    {selectedLang.status.replace('-', ' ').toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              <div>
                <span className="text-slate-400 text-sm">Sample Text:</span>
                <div className="mt-2 p-3 bg-slate-700/30 rounded-lg">
                  <p className="text-white text-lg">{selectedLang.sampleText}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Voice Demo */}
          <Card className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white">Voice Demo</CardTitle>
              <p className="text-slate-400">Test speech synthesis and recognition</p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Text-to-Speech Demo */}
              <div className="space-y-3">
                <h4 className="text-white font-medium">Text-to-Speech</h4>
                <div className="p-4 bg-slate-700/30 rounded-lg">
                  <p className="text-slate-300 mb-3">{selectedLang.sampleText}</p>
                  <Button
                    onClick={() => handleVoiceDemo(selectedLang.code)}
                    disabled={isPlaying === selectedLang.code}
                    className={`w-full ${
                      isPlaying === selectedLang.code 
                        ? 'bg-slate-600 text-slate-300' 
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                  >
                    {isPlaying === selectedLang.code ? (
                      <>
                        <Volume2 className="w-4 h-4 mr-2 animate-pulse" />
                        Playing...
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Play Voice Demo
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Speech Recognition Demo */}
              <div className="space-y-3">
                <h4 className="text-white font-medium">Speech Recognition</h4>
                <div className="p-4 bg-slate-700/30 rounded-lg">
                  <p className="text-slate-300 mb-3">
                    "मेरी फसल में कौन सी बीमारी है?" (What disease is in my crop?)
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    <Mic className="w-4 h-4 mr-2" />
                    Test Speech Input
                  </Button>
                </div>
              </div>

              {/* Feature Support */}
              <div className="space-y-2">
                <h4 className="text-white font-medium text-sm">Features Available:</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-3 h-3 text-green-400" />
                    <span className="text-slate-300">Voice Commands</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-3 h-3 text-green-400" />
                    <span className="text-slate-300">Natural Conversation</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-3 h-3 text-green-400" />
                    <span className="text-slate-300">Offline Support</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Global Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-6"
      >
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-blue-400 mb-2">8+</div>
          <div className="text-sm text-slate-300">Languages Supported</div>
        </div>
        
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-green-400 mb-2">1B+</div>
          <div className="text-sm text-slate-300">Total Speakers</div>
        </div>
        
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-purple-400 mb-2">95%</div>
          <div className="text-sm text-slate-300">Recognition Accuracy</div>
        </div>
        
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-orange-400 mb-2">100%</div>
          <div className="text-sm text-slate-300">Offline Capable</div>
        </div>
      </motion.div>
    </div>
  );
}