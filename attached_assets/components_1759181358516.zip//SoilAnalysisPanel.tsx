import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Skeleton } from './ui/skeleton';
import { 
  Droplets, 
  Beaker, 
  Leaf, 
  TrendingUp,
  Activity,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

interface SoilData {
  moisture: number;
  ph: number;
  npk: {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
  };
  temperature: number;
  conductivity: number;
  organicMatter: number;
}

interface SoilAnalysisPanelProps {
  data?: SoilData;
  isLoading?: boolean;
}

export function SoilAnalysisPanel({ data, isLoading }: SoilAnalysisPanelProps) {
  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 h-full">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (value: number, min: number, max: number) => {
    if (value >= min && value <= max) return 'text-green-400';
    if (value < min * 0.8 || value > max * 1.2) return 'text-red-400';
    return 'text-yellow-400';
  };

  const getStatusIcon = (value: number, min: number, max: number) => {
    if (value >= min && value <= max) return <CheckCircle className="w-4 h-4 text-green-400" />;
    return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
  };

  return (
    <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600 h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <Leaf className="w-5 h-5 text-green-400" />
            </div>
            Real-time Soil Analysis
          </CardTitle>
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <Activity className="w-3 h-3 mr-1" />
            Live Data
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Primary Metrics */}
        <div className="grid grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-center"
          >
            <div className="flex items-center justify-center gap-2 mb-2">
              <Droplets className="w-4 h-4 text-blue-400" />
              <Badge variant="outline" className="text-xs">Demo</Badge>
            </div>
            <div className="text-2xl font-bold text-blue-400">{data?.moisture || 34}%</div>
            <p className="text-xs text-slate-400">Soil Moisture</p>
            <p className="text-xs text-slate-300 mt-1">Needs irrigation in 2 days</p>
            <Progress 
              value={data?.moisture || 34} 
              className="mt-2 h-2"
              style={{
                background: 'rgba(30, 41, 59, 0.5)',
              }}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-center"
          >
            <div className="flex items-center justify-center gap-2 mb-2">
              <Beaker className="w-4 h-4 text-purple-400" />
              <Badge variant="outline" className="text-xs">Demo</Badge>
            </div>
            <div className="text-2xl font-bold text-purple-400">{data?.ph || 6.8}</div>
            <p className="text-xs text-slate-400">pH Level</p>
            <p className="text-xs text-slate-300 mt-1">Optimal for most crops</p>
            <Progress 
              value={((data?.ph || 6.8) / 14) * 100} 
              className="mt-2 h-2"
              style={{
                background: 'rgba(30, 41, 59, 0.5)',
              }}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-center"
          >
            <div className="flex items-center justify-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <Badge variant="outline" className="text-xs">Demo</Badge>
            </div>
            <div className="text-2xl font-bold text-green-400">Good</div>
            <p className="text-xs text-slate-400">NPK Levels</p>
            <p className="text-xs text-slate-300 mt-1">N:120 P:45 K:78 ppm</p>
            <div className="mt-2 flex gap-1">
              <div className="flex-1 h-2 bg-green-500/60 rounded" />
              <div className="flex-1 h-2 bg-yellow-500/60 rounded" />
              <div className="flex-1 h-2 bg-green-500/60 rounded" />
            </div>
          </motion.div>
        </div>

        {/* Detailed Analysis */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-slate-300 flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Satellite Data Analysis
          </h4>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 rounded">
                  <Droplets className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">NDVI Index</p>
                  <p className="text-xs text-slate-400">Sentinel-2</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-blue-400">0.72</p>
                <p className="text-xs text-slate-400">Healthy vegetation detected</p>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/20 rounded">
                  <TrendingUp className="w-4 h-4 text-green-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Field Boundary</p>
                  <p className="text-xs text-slate-400">Bhutan API</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-green-400">4.8 Ha</p>
                <p className="text-xs text-slate-400">Auto-detected area</p>
              </div>
            </div>
          </div>
        </div>

        {/* Status Indicators */}
        <div className="flex items-center justify-between p-3 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg border border-green-500/20">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span className="text-sm text-green-400 font-medium">Optimal Growing Conditions</span>
          </div>
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            Active
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}