import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Skeleton } from './ui/skeleton';
import { 
  Satellite, 
  Map, 
  Activity,
  Zap,
  MapPin,
  Layers,
  RefreshCw,
  Download,
  Eye,
  TrendingUp
} from 'lucide-react';

interface SatelliteData {
  ndvi: number;
  fieldBoundary: number;
  vegetationHealth: string;
  lastUpdated: string;
}

interface SatelliteMonitorProps {
  data?: SatelliteData;
  isLoading?: boolean;
  expanded?: boolean;
}

export function SatelliteMonitor({ data, isLoading, expanded = false }: SatelliteMonitorProps) {
  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 h-full">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
    );
  }

  const defaultData: SatelliteData = {
    ndvi: 0.72,
    fieldBoundary: 4.8,
    vegetationHealth: 'Healthy vegetation detected',
    lastUpdated: '2 hours ago'
  };

  const satelliteData = data || defaultData;

  const getNDVIStatus = (ndvi: number) => {
    if (ndvi >= 0.7) return { status: 'Excellent', color: 'text-green-400', bgColor: 'bg-green-500/20' };
    if (ndvi >= 0.5) return { status: 'Good', color: 'text-yellow-400', bgColor: 'bg-yellow-500/20' };
    return { status: 'Poor', color: 'text-red-400', bgColor: 'bg-red-500/20' };
  };

  const ndviStatus = getNDVIStatus(satelliteData.ndvi);

  return (
    <Card className="bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Satellite className="w-5 h-5 text-blue-400" />
            </div>
            Satellite Data Analysis
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
              <Activity className="w-3 h-3 mr-1" />
              Live Feed
            </Badge>
            {expanded && (
              <Button size="sm" variant="outline" className="border-slate-600 text-slate-300">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* NDVI Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="p-2 bg-blue-500/20 rounded">
                <Layers className="w-5 h-5 text-blue-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium text-white">NDVI Index</p>
                  <Badge variant="outline" className="text-xs">Sentinel-2</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-blue-400">{satelliteData.ndvi}</span>
                  <Badge className={`${ndviStatus.bgColor} ${ndviStatus.color} border-${ndviStatus.color.replace('text-', '')}/30`}>
                    {ndviStatus.status}
                  </Badge>
                </div>
                <p className="text-xs text-slate-400 mt-1">{satelliteData.vegetationHealth}</p>
                <Progress value={satelliteData.ndvi * 100} className="mt-2 h-2" />
              </div>
            </div>

            <div className="flex items-center gap-2 p-3 bg-slate-700/30 rounded-lg border border-slate-600">
              <div className="p-2 bg-green-500/20 rounded">
                <MapPin className="w-5 h-5 text-green-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium text-white">Field Boundary</p>
                  <Badge variant="outline" className="text-xs">Bhutan API</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-green-400">{satelliteData.fieldBoundary} Ha</span>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    Auto-detected
                  </Badge>
                </div>
                <p className="text-xs text-slate-400 mt-1">Auto-detected area</p>
                <Progress value={85} className="mt-2 h-2" />
              </div>
            </div>
          </div>

          {/* Satellite View */}
          <div className="space-y-4">
            <div className="aspect-square bg-slate-700/30 rounded-lg border border-slate-600 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 via-yellow-500/20 to-red-500/20">
                <div className="absolute inset-4 border-2 border-dashed border-white/30 rounded-lg"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="text-center text-white">
                    <Map className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                    <p className="text-sm">Satellite View</p>
                    <p className="text-xs text-slate-400">NDVI Overlay</p>
                  </div>
                </div>
                
                {/* Scanning Animation */}
                <motion.div
                  animate={{ 
                    backgroundPosition: ['0% 0%', '100% 100%'],
                    opacity: [0.3, 0.7, 0.3]
                  }}
                  transition={{ 
                    duration: 3, 
                    repeat: Infinity, 
                    ease: "linear" 
                  }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/30 to-transparent"
                  style={{ 
                    background: 'linear-gradient(45deg, transparent 30%, rgba(59, 130, 246, 0.3) 50%, transparent 70%)',
                    backgroundSize: '200% 200%'
                  }}
                />
              </div>
              
              <div className="absolute top-2 left-2">
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                  <Satellite className="w-3 h-3 mr-1" />
                  Live
                </Badge>
              </div>
            </div>
          </div>
        </motion.div>

        {expanded && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            {/* Historical Data */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 bg-slate-700/30 rounded-lg border border-slate-600">
                <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-green-400">+12%</div>
                <p className="text-xs text-slate-400">NDVI Growth</p>
                <p className="text-xs text-slate-300">Last 30 days</p>
              </div>
              
              <div className="text-center p-3 bg-slate-700/30 rounded-lg border border-slate-600">
                <Eye className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-blue-400">98.5%</div>
                <p className="text-xs text-slate-400">Coverage</p>
                <p className="text-xs text-slate-300">Field monitoring</p>
              </div>
              
              <div className="text-center p-3 bg-slate-700/30 rounded-lg border border-slate-600">
                <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-yellow-400">5 min</div>
                <p className="text-xs text-slate-400">Update Rate</p>
                <p className="text-xs text-slate-300">Real-time data</p>
              </div>
            </div>

            {/* Analysis Tools */}
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                <Map className="w-4 h-4 mr-2" />
                View Full Map
              </Button>
            </div>
          </motion.div>
        )}

        {/* Status Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: expanded ? 0.3 : 0.2 }}
          className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg border border-blue-500/20"
        >
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-sm text-slate-300">Last updated: {satelliteData.lastUpdated}</span>
          </div>
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            Real-time Active
          </Badge>
        </motion.div>
      </CardContent>
    </Card>
  );
}