import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Mic, 
  Camera, 
  Brain,
  Satellite,
  Wifi,
  WifiOff,
  TrendingUp,
  Play,
  CheckCircle,
  Zap,
  Globe,
  Activity,
  Target,
  BarChart3
} from 'lucide-react';

interface DemoCard {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
  features: string[];
  buttonText: string;
  isActive?: boolean;
}

export function DemoSection() {
  const [activeDemo, setActiveDemo] = useState<string | null>(null);
  const [demoProgress, setDemoProgress] = useState(0);

  const demoCards: DemoCard[] = [
    {
      id: 'voice',
      title: 'Voice Assistant Demo',
      description: 'Multilingual speech recognition and natural language processing',
      icon: Mic,
      color: 'text-purple-400',
      bgColor: 'from-purple-900/20 to-purple-800/20',
      features: ['8+ Indian Languages', 'Offline Speech Recognition', 'Real-time Processing'],
      buttonText: 'Test Voice Features'
    },
    {
      id: 'disease',
      title: 'Disease Scanner Demo',
      description: 'Computer vision for crop disease detection and treatment',
      icon: Camera,
      color: 'text-pink-400',
      bgColor: 'from-pink-900/20 to-pink-800/20',
      features: ['Real-time Image Analysis', 'Disease Identification', 'Treatment Recommendations'],
      buttonText: 'Test Scanner'
    },
    {
      id: 'ai',
      title: 'AI Analysis Demo',
      description: 'Machine learning crop recommendations and market analysis',
      icon: Brain,
      color: 'text-blue-400',
      bgColor: 'from-blue-900/20 to-blue-800/20',
      features: ['Crop Recommendation Engine', 'Market Price Analysis', 'Sustainability Scoring'],
      buttonText: 'Test AI Engine'
    },
    {
      id: 'satellite',
      title: 'Satellite Data Demo',
      description: 'Real-time earth observation and field boundary detection',
      icon: Satellite,
      color: 'text-green-400',
      bgColor: 'from-green-900/20 to-green-800/20',
      features: ['NDVI Analysis', 'Field Boundary Detection', 'Weather Integration'],
      buttonText: 'Test Satellite'
    },
    {
      id: 'offline',
      title: 'Offline Mode Demo',
      description: 'Full functionality without internet connection',
      icon: WifiOff,
      color: 'text-orange-400',
      bgColor: 'from-orange-900/20 to-orange-800/20',
      features: ['Local Database', 'Offline Voice Models', 'Cached Recommendations'],
      buttonText: 'Test Offline'
    },
    {
      id: 'market',
      title: 'Market Intelligence Demo',
      description: 'Real-time price trends and demand forecasting',
      icon: TrendingUp,
      color: 'text-cyan-400',
      bgColor: 'from-cyan-900/20 to-cyan-800/20',
      features: ['Price Trend Analysis', 'Demand Forecasting', 'Profit Optimization'],
      buttonText: 'Test Market AI'
    }
  ];

  const handleDemoStart = (demoId: string) => {
    setActiveDemo(demoId);
    setDemoProgress(0);
    
    // Simulate demo progress
    const interval = setInterval(() => {
      setDemoProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setActiveDemo(null);
            setDemoProgress(0);
          }, 1000);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  return (
    <div className="space-y-8">
      {/* Demo Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold text-white mb-4">
          Interactive Live Demo Platform
        </h2>
        <p className="text-lg text-slate-300 mb-6">
          Experience all features with simulated real data
        </p>
        <div className="flex items-center justify-center gap-6 text-sm text-slate-400">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            Live Demo
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            Complete Data
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            Real Features
          </div>
        </div>
      </motion.div>

      {/* Demo Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {demoCards.map((demo, index) => (
          <motion.div
            key={demo.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className={`bg-gradient-to-br ${demo.bgColor} border-slate-600 h-full hover:scale-105 transition-all duration-300 ${
              activeDemo === demo.id ? 'ring-2 ring-blue-500' : ''
            }`}>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 bg-slate-700/50 rounded-full ${demo.color}`}>
                    <demo.icon className="w-8 h-8" />
                  </div>
                  {activeDemo === demo.id && (
                    <Badge className="bg-blue-600 text-white animate-pulse">
                      <Activity className="w-3 h-3 mr-1" />
                      Running
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-white text-xl">{demo.title}</CardTitle>
                <p className="text-slate-300 text-sm">{demo.description}</p>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Features List */}
                <div className="space-y-2">
                  {demo.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-3 h-3 text-green-400" />
                      <span className="text-slate-300">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Progress Bar (when demo is active) */}
                {activeDemo === demo.id && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-300">Demo Progress</span>
                      <span className={`${demo.color} font-medium`}>{demoProgress}%</span>
                    </div>
                    <Progress value={demoProgress} className="h-2" />
                  </div>
                )}

                {/* Demo Button */}
                <Button
                  onClick={() => handleDemoStart(demo.id)}
                  disabled={activeDemo === demo.id}
                  className={`w-full ${
                    activeDemo === demo.id 
                      ? 'bg-slate-600 text-slate-300' 
                      : `bg-gradient-to-r ${demo.bgColor} border border-slate-600 text-white hover:scale-105`
                  } transition-all duration-300`}
                >
                  {activeDemo === demo.id ? (
                    <>
                      <Activity className="w-4 h-4 mr-2 animate-spin" />
                      Running Demo...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      {demo.buttonText}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Advanced Features Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-12"
      >
        <Card className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 border-blue-500/30">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto p-3 bg-blue-500/20 rounded-full w-fit mb-3">
              <Brain className="w-6 h-6 text-blue-400" />
            </div>
            <CardTitle className="text-white text-lg">AI/ML Engine</CardTitle>
            <p className="text-sm text-slate-400">Advanced crop prediction and disease detection</p>
          </CardHeader>
          <CardContent className="space-y-2 text-xs text-slate-300">
            <div className="p-2 bg-slate-700/30 rounded text-center">TensorFlow</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">PyTorch</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">OpenCV</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-900/20 to-cyan-900/20 border-green-500/30">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto p-3 bg-green-500/20 rounded-full w-fit mb-3">
              <Satellite className="w-6 h-6 text-green-400" />
            </div>
            <CardTitle className="text-white text-lg">Satellite Data</CardTitle>
            <p className="text-sm text-slate-400">Real-time earth observation and analysis</p>
          </CardHeader>
          <CardContent className="space-y-2 text-xs text-slate-300">
            <div className="p-2 bg-slate-700/30 rounded text-center">Sentinel-2</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">Landsat</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">Google Earth</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-900/20 to-pink-900/20 border-purple-500/30">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto p-3 bg-purple-500/20 rounded-full w-fit mb-3">
              <Target className="w-6 h-6 text-purple-400" />
            </div>
            <CardTitle className="text-white text-lg">Demo Platform</CardTitle>
            <p className="text-sm text-slate-400">Interactive prototypes with simulated data</p>
          </CardHeader>
          <CardContent className="space-y-2 text-xs text-slate-300">
            <div className="p-2 bg-slate-700/30 rounded text-center">Live Demo</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">Complete Data</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">Real Features</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-900/20 to-red-900/20 border-orange-500/30">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto p-3 bg-orange-500/20 rounded-full w-fit mb-3">
              <Globe className="w-6 h-6 text-orange-400" />
            </div>
            <CardTitle className="text-white text-lg">Mobile App</CardTitle>
            <p className="text-sm text-slate-400">Multilingual, voice-enabled, offline-ready</p>
          </CardHeader>
          <CardContent className="space-y-2 text-xs text-slate-300">
            <div className="p-2 bg-slate-700/30 rounded text-center">React Native</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">Speech API</div>
            <div className="p-2 bg-slate-700/30 rounded text-center">SQLite</div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Full Demo CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0 }}
        className="text-center p-8 bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/20 rounded-2xl"
      >
        <h3 className="text-2xl font-bold text-white mb-4">Ready for the Complete Experience?</h3>
        <p className="text-slate-300 mb-6">
          Access the full SIH 2025 demo with all features, real data integration, and advanced AI capabilities.
        </p>
        <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
          <Zap className="w-5 h-5 mr-2" />
          Launch Full SIH Demo
        </Button>
      </motion.div>
    </div>
  );
}