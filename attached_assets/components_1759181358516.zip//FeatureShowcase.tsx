import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Brain, 
  Camera, 
  Mic, 
  WifiOff,
  Satellite,
  TrendingUp,
  Shield,
  Globe,
  Zap,
  CheckCircle
} from 'lucide-react';

interface Feature {
  icon: React.ComponentType<any>;
  title: string;
  description: string;
  color: string;
  bgColor: string;
  features: string[];
}

export function FeatureShowcase() {
  const coreFeatures: Feature[] = [
    {
      icon: Brain,
      title: 'AI Crop Recommendations',
      description: 'Advanced machine learning algorithms for personalized crop suggestions',
      color: 'text-blue-400',
      bgColor: 'from-blue-900/20 to-blue-800/20',
      features: ['95% Accuracy Rate', 'Real-time Analysis', 'Weather Integration', 'Soil Compatibility']
    },
    {
      icon: Camera,
      title: 'Disease Detection',
      description: 'Computer vision powered plant disease identification and treatment',
      color: 'text-red-400',
      bgColor: 'from-red-900/20 to-red-800/20',
      features: ['Instant Detection', '50+ Disease Types', 'Treatment Plans', 'Prevention Tips']
    },
    {
      icon: Mic,
      title: 'Voice Assistant (8+ Languages)',
      description: 'Multilingual voice interface for hands-free farming assistance',
      color: 'text-purple-400',
      bgColor: 'from-purple-900/20 to-purple-800/20',
      features: ['Hindi Support', 'Bengali Support', 'Tamil Support', 'Natural Language']
    },
    {
      icon: WifiOff,
      title: 'Offline Mode',
      description: 'Full functionality without internet connection for remote areas',
      color: 'text-orange-400',
      bgColor: 'from-orange-900/20 to-orange-800/20',
      features: ['Local Database', 'Cached Models', 'Sync on Connect', '100% Offline']
    }
  ];

  const technologies = [
    {
      category: 'Machine Learning',
      items: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Computer Vision']
    },
    {
      category: 'Satellite Data Integration',
      items: ['Sentinel-2 API', 'Landsat Integration', 'NDVI Analysis', 'Weather APIs']
    },
    {
      category: 'Interactive Demo Platform',
      items: ['Real-time Simulation', 'Live Data Feeds', 'User Interaction', 'Performance Metrics']
    },
    {
      category: 'Natural Language Processing',
      items: ['Speech Recognition', 'Text Processing', 'Multilingual Support', 'Context Understanding']
    }
  ];

  const languages = [
    { code: 'hi', name: 'हिंदी', english: 'Hindi' },
    { code: 'bn', name: 'বাংলা', english: 'Bengali' },
    { code: 'mr', name: 'मराठी', english: 'Marathi' },
    { code: 'gu', name: 'ગુજરાતી', english: 'Gujarati' },
    { code: 'ta', name: 'தமிழ்', english: 'Tamil' },
    { code: 'te', name: 'తెలుగు', english: 'Telugu' },
    { code: 'kn', name: 'ಕನ್ನಡ', english: 'Kannada' },
    { code: 'pa', name: 'ਪੰਜਾਬੀ', english: 'Punjabi' }
  ];

  return (
    <div className="space-y-12">
      {/* Core Features */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Core Features</h2>
          <p className="text-lg text-slate-300">
            Comprehensive agricultural AI platform with cutting-edge technology
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {coreFeatures.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={`bg-gradient-to-br ${feature.bgColor} border-slate-600 h-full hover:scale-105 transition-all duration-300`}>
                <CardHeader className="text-center pb-4">
                  <div className={`mx-auto p-3 bg-slate-700/50 rounded-full w-fit mb-3 ${feature.color}`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-white text-lg">{feature.title}</CardTitle>
                  <p className="text-sm text-slate-400">{feature.description}</p>
                </CardHeader>
                <CardContent className="space-y-2">
                  {feature.features.map((item, itemIndex) => (
                    <div key={itemIndex} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-3 h-3 text-green-400" />
                      <span className="text-slate-300">{item}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Technology Stack */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="space-y-6"
      >
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Technology Stack</h2>
          <p className="text-lg text-slate-300">
            Built with modern technologies for scalability and performance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {technologies.map((tech, index) => (
            <motion.div
              key={tech.category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + index * 0.1 }}
            >
              <Card className="bg-slate-800/50 border-slate-600 h-full">
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-white text-lg">{tech.category}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {tech.items.map((item, itemIndex) => (
                    <div 
                      key={itemIndex} 
                      className="p-2 bg-slate-700/30 rounded text-center text-sm text-slate-300"
                    >
                      {item}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Languages Supported */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0 }}
        className="space-y-6"
      >
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Languages Supported</h2>
          <p className="text-lg text-slate-300">
            Comprehensive multilingual support for Indian farmers
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {languages.map((lang, index) => (
            <motion.div
              key={lang.code}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1.1 + index * 0.05 }}
            >
              <Card className="bg-slate-800/50 border-slate-600 hover:scale-105 transition-all duration-300">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl mb-2">🇮🇳</div>
                  <div className="text-lg font-medium text-white mb-1">{lang.name}</div>
                  <div className="text-xs text-slate-400">{lang.english}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="text-center">
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-lg p-3">
            <Globe className="w-5 h-5 mr-2" />
            8+ Indian Languages Supported
          </Badge>
        </div>
      </motion.div>

      {/* Performance Metrics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-6"
      >
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-green-400 mb-2">95%</div>
          <div className="text-sm text-slate-300">Prediction Accuracy</div>
        </div>
        
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-blue-400 mb-2">50+</div>
          <div className="text-sm text-slate-300">Disease Types Detected</div>
        </div>
        
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-purple-400 mb-2">8+</div>
          <div className="text-sm text-slate-300">Languages Supported</div>
        </div>
        
        <div className="text-center p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
          <div className="text-3xl font-bold text-orange-400 mb-2">100%</div>
          <div className="text-sm text-slate-300">Offline Capability</div>
        </div>
      </motion.div>
    </div>
  );
}