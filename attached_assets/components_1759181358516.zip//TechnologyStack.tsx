import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Brain, 
  Satellite,
  Smartphone,
  Cloud,
  Database,
  Globe,
  Code,
  Zap
} from 'lucide-react';

interface TechCategory {
  icon: React.ComponentType<any>;
  title: string;
  description: string;
  color: string;
  bgColor: string;
  technologies: {
    name: string;
    description: string;
    version?: string;
  }[];
}

export function TechnologyStack() {
  const techStack: TechCategory[] = [
    {
      icon: Brain,
      title: 'AI/ML Framework',
      description: 'Advanced machine learning and computer vision',
      color: 'text-blue-400',
      bgColor: 'from-blue-900/20 to-blue-800/20',
      technologies: [
        { name: 'TensorFlow', description: 'Deep learning models for crop prediction', version: '2.13+' },
        { name: 'PyTorch', description: 'Computer vision for disease detection', version: '2.0+' },
        { name: 'OpenCV', description: 'Image processing and analysis', version: '4.8+' },
        { name: 'Scikit-learn', description: 'Traditional ML algorithms', version: '1.3+' }
      ]
    },
    {
      icon: Satellite,
      title: 'Satellite Data',
      description: 'Real-time earth observation and analysis',
      color: 'text-green-400',
      bgColor: 'from-green-900/20 to-green-800/20',
      technologies: [
        { name: 'Sentinel-2', description: 'High-resolution multispectral imagery' },
        { name: 'Landsat', description: 'Long-term earth observation data' },
        { name: 'Google Earth Engine', description: 'Planetary-scale geospatial analysis' },
        { name: 'NDVI Analysis', description: 'Vegetation health monitoring' }
      ]
    },
    {
      icon: Smartphone,
      title: 'Mobile Platform',
      description: 'Cross-platform mobile application',
      color: 'text-purple-400',
      bgColor: 'from-purple-900/20 to-purple-800/20',
      technologies: [
        { name: 'React Native', description: 'Cross-platform mobile development', version: '0.72+' },
        { name: 'Expo', description: 'Development platform and tools', version: '49+' },
        { name: 'SQLite', description: 'Local database for offline storage' },
        { name: 'React Native Voice', description: 'Speech recognition integration' }
      ]
    },
    {
      icon: Cloud,
      title: 'Backend Services',
      description: 'Scalable cloud infrastructure',
      color: 'text-cyan-400',
      bgColor: 'from-cyan-900/20 to-cyan-800/20',
      technologies: [
        { name: 'Supabase', description: 'Backend-as-a-service platform' },
        { name: 'PostgreSQL', description: 'Relational database system' },
        { name: 'Edge Functions', description: 'Serverless compute at the edge' },
        { name: 'Real-time APIs', description: 'Live data synchronization' }
      ]
    },
    {
      icon: Globe,
      title: 'Language Processing',
      description: 'Multilingual natural language processing',
      color: 'text-orange-400',
      bgColor: 'from-orange-900/20 to-orange-800/20',
      technologies: [
        { name: 'Speech Recognition', description: 'Voice input in multiple languages' },
        { name: 'Natural Language Understanding', description: 'Context-aware processing' },
        { name: 'Text-to-Speech', description: 'Voice output synthesis' },
        { name: 'Language Models', description: 'Multilingual conversation AI' }
      ]
    },
    {
      icon: Database,
      title: 'Data Management',
      description: 'Comprehensive data storage and processing',
      color: 'text-yellow-400',
      bgColor: 'from-yellow-900/20 to-yellow-800/20',
      technologies: [
        { name: 'Time Series DB', description: 'Weather and sensor data storage' },
        { name: 'Vector Database', description: 'AI model embeddings storage' },
        { name: 'Data Pipeline', description: 'Automated data processing workflows' },
        { name: 'Cache Layer', description: 'High-performance data access' }
      ]
    }
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold text-white mb-4">Technology Architecture</h2>
        <p className="text-lg text-slate-300 mb-6">
          Built with cutting-edge technologies for scalability, performance, and reliability
        </p>
        <div className="flex items-center justify-center gap-6 text-sm text-slate-400">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            High Performance
          </div>
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-blue-400" />
            Cloud Native
          </div>
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-green-400" />
            Open Source
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {techStack.map((category, index) => (
          <motion.div
            key={category.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className={`bg-gradient-to-br ${category.bgColor} border-slate-600 h-full hover:scale-105 transition-all duration-300`}>
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className={`p-3 bg-slate-700/50 rounded-lg ${category.color}`}>
                    <category.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle className="text-white text-lg">{category.title}</CardTitle>
                    <p className="text-sm text-slate-400">{category.description}</p>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                {category.technologies.map((tech, techIndex) => (
                  <motion.div
                    key={tech.name}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (index * 0.1) + (techIndex * 0.05) }}
                    className="p-3 bg-slate-700/30 rounded-lg border border-slate-600 hover:bg-slate-700/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-white">{tech.name}</span>
                      {tech.version && (
                        <Badge variant="outline" className="text-xs">
                          {tech.version}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">{tech.description}</p>
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Architecture Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="p-8 bg-gradient-to-r from-slate-800/50 to-slate-700/50 border border-slate-600 rounded-2xl"
      >
        <h3 className="text-2xl font-bold text-white mb-6 text-center">System Architecture</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="p-4 bg-blue-600/20 rounded-lg mb-4">
              <Smartphone className="w-8 h-8 text-blue-400 mx-auto" />
            </div>
            <h4 className="font-medium text-white mb-2">Frontend Layer</h4>
            <p className="text-sm text-slate-400">
              React Native mobile app with offline capabilities and voice interface
            </p>
          </div>
          
          <div className="text-center">
            <div className="p-4 bg-green-600/20 rounded-lg mb-4">
              <Cloud className="w-8 h-8 text-green-400 mx-auto" />
            </div>
            <h4 className="font-medium text-white mb-2">Backend Services</h4>
            <p className="text-sm text-slate-400">
              Supabase backend with AI/ML processing and real-time data sync
            </p>
          </div>
          
          <div className="text-center">
            <div className="p-4 bg-purple-600/20 rounded-lg mb-4">
              <Database className="w-8 h-8 text-purple-400 mx-auto" />
            </div>
            <h4 className="font-medium text-white mb-2">Data Layer</h4>
            <p className="text-sm text-slate-400">
              Multi-modal data storage with satellite feeds and AI model results
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}