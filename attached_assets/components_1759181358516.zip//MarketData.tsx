import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  IndianRupee,
  BarChart3,
  AlertCircle
} from 'lucide-react';

interface MarketPrice {
  crop: string;
  currentPrice: number;
  previousPrice: number;
  change: number;
  changePercent: number;
  unit: string;
  market: string;
  lastUpdated: string;
  volume: number;
  forecast: 'bullish' | 'bearish' | 'stable';
}

interface MarketDataProps {
  prices: MarketPrice[];
}

export function MarketData({ prices }: MarketDataProps) {
  const getTrendIcon = (change: number) => {
    if (change > 0) return TrendingUp;
    if (change < 0) return TrendingDown;
    return Minus;
  };

  const getTrendColor = (change: number) => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-muted-foreground';
  };

  const getForecastBadge = (forecast: string) => {
    switch (forecast) {
      case 'bullish':
        return <Badge className="bg-green-100 text-green-800 border-green-200">📈 Bullish</Badge>;
      case 'bearish':
        return <Badge className="bg-red-100 text-red-800 border-red-200">📉 Bearish</Badge>;
      default:
        return <Badge variant="secondary">➡️ Stable</Badge>;
    }
  };

  return (
    <Card className="col-span-full lg:col-span-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          Market Prices
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {prices.map((price, index) => {
            const TrendIcon = getTrendIcon(price.change);
            const trendColor = getTrendColor(price.change);
            
            return (
              <div key={index} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium">{price.crop}</h4>
                    <p className="text-sm text-muted-foreground">{price.market}</p>
                  </div>
                  {getForecastBadge(price.forecast)}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center gap-1">
                      <IndianRupee className="w-4 h-4" />
                      <span className="text-lg font-bold">
                        {price.currentPrice.toLocaleString()}
                      </span>
                      <span className="text-sm text-muted-foreground">/{price.unit}</span>
                    </div>
                    <div className={`flex items-center gap-1 text-sm ${trendColor}`}>
                      <TrendIcon className="w-4 h-4" />
                      <span>{Math.abs(price.change).toLocaleString()}</span>
                      <span>({Math.abs(price.changePercent)}%)</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Volume</p>
                    <p className="font-medium">{price.volume.toLocaleString()} tons</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Updated: {price.lastUpdated}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-900">Market Insights</h4>
              <p className="text-sm text-blue-800 mt-1">
                Wheat prices are expected to rise by 8-12% in the next month due to seasonal demand. 
                Consider holding your harvest if storage capacity allows.
              </p>
              <Button size="sm" variant="outline" className="mt-2 text-blue-700 border-blue-300">
                View Full Analysis
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}