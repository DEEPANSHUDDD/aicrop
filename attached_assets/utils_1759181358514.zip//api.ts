import { projectId, publicAnonKey } from './supabase/info';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-8c17ee28`;

class ApiService {
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    try {
      const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
          ...options.headers,
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`API request failed [${response.status}]:`, errorText);
        throw new Error(`API request failed: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`API request error for ${endpoint}:`, error);
      throw error;
    }
  }

  // Weather API
  async getWeather(location: string) {
    return this.request(`/weather/${encodeURIComponent(location)}`);
  }

  // Market prices API
  async getMarketPrices() {
    return this.request('/market-prices');
  }

  // AI Recommendations API
  async getRecommendations(farmId: string = 'default') {
    return this.request(`/recommendations/${farmId}`);
  }

  // Field data API
  async getFields(farmId: string = 'default') {
    return this.request(`/fields/${farmId}`);
  }

  // Analytics API
  async getAnalytics(farmId: string = 'default') {
    return this.request(`/analytics/${farmId}`);
  }

  // Disease detection API
  async detectDisease(imageData: string, fieldId: string = 'default') {
    return this.request('/detect-disease', {
      method: 'POST',
      body: JSON.stringify({ imageData, fieldId }),
    });
  }

  // Voice command API
  async processVoiceCommand(command: string, farmId: string = 'default') {
    return this.request('/voice-command', {
      method: 'POST',
      body: JSON.stringify({ command, farmId }),
    });
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }
}

export const apiService = new ApiService();