// Fallback data for when backend is not available
export const fallbackWeatherData = {
  location: 'Pune, Maharashtra',
  temperature: 32,
  condition: 'sunny',
  humidity: 68,
  windSpeed: 12,
  visibility: 10,
  pressure: 1013,
  forecast: [
    { day: 'Today', high: 32, low: 24, condition: 'sunny', icon: '☀️' },
    { day: 'Tomorrow', high: 30, low: 22, condition: 'cloudy', icon: '☁️' },
    { day: 'Thu', high: 28, low: 20, condition: 'rainy', icon: '🌧️' },
    { day: 'Fri', high: 31, low: 23, condition: 'sunny', icon: '☀️' },
    { day: 'Sat', high: 33, low: 25, condition: 'sunny', icon: '☀️' },
  ],
  alerts: [
    { type: 'Heat Wave', message: 'High temperature expected for next 2 days', severity: 'medium' as const },
    { type: 'Rain Alert', message: 'Light rain expected on Thursday', severity: 'low' as const }
  ],
  timestamp: new Date().toISOString()
};

export const fallbackRecommendations = [
  {
    id: '1',
    type: 'irrigation' as const,
    title: 'Optimize Irrigation Schedule',
    description: 'Based on soil moisture data and weather forecast, adjust watering times for better water conservation.',
    confidence: 94,
    priority: 'high' as const,
    timeframe: 'Next 2 days',
    expectedBenefit: '+15% water efficiency',
    status: 'pending' as const
  },
  {
    id: '2',
    type: 'crop' as const,
    title: 'Corn Planting Recommendation',
    description: 'Optimal conditions detected for corn planting in the east field. Soil temperature and moisture are ideal.',
    confidence: 88,
    priority: 'medium' as const,
    timeframe: 'This week',
    expectedBenefit: '+12% yield potential',
    status: 'in-progress' as const
  },
  {
    id: '3',
    type: 'fertilizer' as const,
    title: 'Nitrogen Application',
    description: 'Wheat crops showing nitrogen deficiency signs. Apply balanced NPK fertilizer for optimal growth.',
    confidence: 76,
    priority: 'medium' as const,
    timeframe: 'Within 5 days',
    expectedBenefit: '+8% crop health',
    status: 'pending' as const
  }
];

export const fallbackMarketPrices = [
  {
    crop: 'Wheat',
    currentPrice: 2150,
    previousPrice: 2080,
    change: 70,
    changePercent: '3.4',
    unit: 'quintal',
    market: 'Pune Mandi',
    lastUpdated: '10:30 AM',
    volume: 1250,
    forecast: 'bullish' as const
  },
  {
    crop: 'Rice',
    currentPrice: 1850,
    previousPrice: 1875,
    change: -25,
    changePercent: '-1.3',
    unit: 'quintal',
    market: 'Mumbai APMC',
    lastUpdated: '11:15 AM',
    volume: 890,
    forecast: 'stable' as const
  },
  {
    crop: 'Tomatoes',
    currentPrice: 3200,
    previousPrice: 2950,
    change: 250,
    changePercent: '8.5',
    unit: 'quintal',
    market: 'Local Market',
    lastUpdated: '09:45 AM',
    volume: 450,
    forecast: 'bullish' as const
  }
];

export const fallbackFields = [
  {
    id: '1',
    name: 'North Field A',
    crop: 'Wheat',
    area: 12.5,
    status: 'healthy' as const,
    soilMoisture: 65,
    temperature: 28,
    ndvi: 0.82,
    lastUpdated: '2 hours ago'
  },
  {
    id: '2',
    name: 'South Field B',
    crop: 'Rice',
    area: 18.3,
    status: 'attention' as const,
    soilMoisture: 45,
    temperature: 32,
    ndvi: 0.64,
    lastUpdated: '1 hour ago'
  },
  {
    id: '3',
    name: 'East Field C',
    crop: 'Corn',
    area: 15.7,
    status: 'healthy' as const,
    soilMoisture: 72,
    temperature: 29,
    ndvi: 0.89,
    lastUpdated: '30 minutes ago'
  },
  {
    id: '4',
    name: 'West Field D',
    crop: 'Tomatoes',
    area: 8.2,
    status: 'critical' as const,
    soilMoisture: 35,
    temperature: 35,
    ndvi: 0.45,
    lastUpdated: '15 minutes ago'
  }
];

export const fallbackAnalytics = {
  yieldData: [
    { month: 'Jan', wheat: 45, rice: 38, corn: 52 },
    { month: 'Feb', wheat: 48, rice: 42, corn: 48 },
    { month: 'Mar', wheat: 52, rice: 45, corn: 55 },
    { month: 'Apr', wheat: 58, rice: 48, corn: 62 },
    { month: 'May', wheat: 65, rice: 52, corn: 68 },
    { month: 'Jun', wheat: 72, rice: 58, corn: 75 },
  ],
  revenueData: [
    { month: 'Jan', revenue: 85000, expenses: 45000, profit: 40000 },
    { month: 'Feb', revenue: 92000, expenses: 48000, profit: 44000 },
    { month: 'Mar', revenue: 98000, expenses: 52000, profit: 46000 },
    { month: 'Apr', revenue: 105000, expenses: 55000, profit: 50000 },
    { month: 'May', revenue: 118000, expenses: 58000, profit: 60000 },
    { month: 'Jun', revenue: 125000, expenses: 62000, profit: 63000 },
  ],
  cropDistribution: [
    { name: 'Wheat', value: 40, color: '#8884d8' },
    { name: 'Rice', value: 25, color: '#82ca9d' },
    { name: 'Corn', value: 20, color: '#ffc658' },
    { name: 'Vegetables', value: 15, color: '#ff7300' },
  ],
  weatherImpact: [
    { date: '2024-01', temperature: 22, rainfall: 45, yield: 78 },
    { date: '2024-02', temperature: 25, rainfall: 38, yield: 82 },
    { date: '2024-03', temperature: 28, rainfall: 52, yield: 75 },
    { date: '2024-04', temperature: 32, rainfall: 28, yield: 85 },
    { date: '2024-05', temperature: 35, rainfall: 15, yield: 70 },
    { date: '2024-06', temperature: 33, rainfall: 65, yield: 88 },
  ]
};